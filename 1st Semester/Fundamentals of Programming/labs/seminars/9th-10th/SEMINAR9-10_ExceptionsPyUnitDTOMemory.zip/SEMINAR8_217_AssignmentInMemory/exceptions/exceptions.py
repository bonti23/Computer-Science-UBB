class TaskManagementException(Exception):
    pass


class RepositoryException(TaskManagementException):
    def __init__(self, msg):
        self.__msg = msg

    def __str__(self):
        return "Repository exception:" + str(self.__msg)


class PersonAlreadyExistsException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Persoana exista deja.")

class PersonDoesNotExistException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Nu exista persoana.")

class TaskAlreadyExistsException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Task-ul exista deja.")

class TaskDoesNotExistException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Nu exista persoana.")

class AssignmentAlreadyExistsException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Assignment-ul exista deja.")

class AssignmentDoesNotExistException(RepositoryException):
    def __init__(self):
        RepositoryException.__init__(self, "Nu exista acest assignment.")


class ValidationException(TaskManagementException):
    def __init__(self, msg):
        self.__msg = msg

    def __str__(self):
        return "Validation exception:" + str(self.__msg)

class InvalidTaskDescription(ValidationException):
    def __init__(self):
        ValidationException.__init__(self, "Descrierea task-ului nu este valida.")

class InvalidDayInDate(ValidationException):
    def __init__(self):
        ValidationException.__init__(self, "Ziua nu este valida.")

class InvalidMonthInDate(ValidationException):
    def __init__(self):
        ValidationException.__init__(self, "Luna nu este valida.")

class InvalidStatus(ValidationException):
    def __init__(self):
        ValidationException.__init__(self, "Statusul este invalid.")