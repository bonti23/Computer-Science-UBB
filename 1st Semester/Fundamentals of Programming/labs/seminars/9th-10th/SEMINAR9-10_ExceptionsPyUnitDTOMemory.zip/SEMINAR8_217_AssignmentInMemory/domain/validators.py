from exceptions.exceptions import ValidationException


class TaskValidator:
    def __init__(self):
        pass

    def validate_task(self, task):
        """
        Valideaza un task dat
        :param task: task-ul care se valideaza
        :return: -
        :raises: ValueError daca task-ul nu e valid
        """
        errors = []
        if len(task.get_descriere()) < 2:
            errors.append("Descrierea nu este corecta. Trebuie sa fie mai lunga de 2 caractere.")

        if task.get_zi_deadline() > 31 or task.get_zi_deadline() < 1:
            errors.append("Ziua deadline nu poate fi decat intre 1-31.")

        if task.get_luna_deadline() > 12 or task.get_luna_deadline() < 1:
            errors.append("Luna deadline nu poate fi decat intre 1-12.")

        if task.get_status() not in ['pending', 'in-progress', 'done']:
            errors.append('Status incorect.')

        if len(errors) > 0:
            error_string = '\n'.join(errors)
            raise ValidationException(error_string)


class PersonValidator:
    def __init__(self):
        pass

    def validate_person(self, person):
        """
        Valideaza datele despre o persoana data
        :param task: persoana care se valideaza
        :return: -
        :raises: ValueError daca datele persoanei nu sunt valide
        """
        errors = []
        if len(person.get_cnp()) != 13:
            errors.append("CNP incorect. Sunt necesare exact 13 cifre.")

        if len(person.get_nume()) < 2:
            errors.append('Nume incorect. Lungime de minim 2 caractere.')

        #Additional validations care s-ar putea face: luna, zi din cnp/data nasterii

        if len(errors) > 0:
            error_string = '\n'.join(errors)
            raise ValidationException(error_string)

class AssignmentValidator:
    def __init__(self):
        pass

    def validate(self, assignment):
        errors = []
        if assignment.get_evaluare() > 10 or assignment.get_evaluare() < 1:
            errors.append("Evaluare incorecta. Nota trebuie sa fie intre 1 si 10.")

        if len(errors) > 0:
            error_string = '\n'.join(errors)
            raise ValidationException(error_string)