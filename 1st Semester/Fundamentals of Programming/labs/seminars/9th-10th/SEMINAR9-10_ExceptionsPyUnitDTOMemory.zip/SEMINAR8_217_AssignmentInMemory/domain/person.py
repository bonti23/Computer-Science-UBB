import datetime


class Person:
    def __init__(self, cnp, nume):
        self.__cnp = cnp
        self.__nume = nume
        self.set_data_nasterii()

    def get_cnp(self):
        return self.__cnp

    def set_data_nasterii(self):
        """
        Returneaza data nasterii persoanei
        :return: data nasterii persoanei
        :rtype: obiect datetime.date
        """
        year = int(self.__cnp[1:3])
        month = int(self.__cnp[3:5])
        day = int(self.__cnp[5:7])
        date_of_birth = datetime.date(year, month, day)
        self.__data_nasterii = date_of_birth

    def get_anul_nasterii(self):

        if self.__data_nasterii.year > 10:
            year = 1900 + self.__data_nasterii.year
        else:
            year = 2000 + self.__data_nasterii.year

        return year

    def get_luna_nasterii(self):
        return self.__data_nasterii.month

    def get_ziua_nasterii(self):
        return self.__data_nasterii.day

    def get_nume(self):
        return self.__nume

    def set_nume(self, nume_nou):
        self.__nume = nume_nou

    def __eq__(self, other):
        return self.__cnp == other.get_cnp()

    def __str__(self):
        return 'CNP: ' + self.__cnp + ' | Nume: ' + self.__nume
