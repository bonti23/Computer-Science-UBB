from exceptions.exceptions import AssignmentAlreadyExistsException


class AssignmentInMemoryRepository:
    def __init__(self):
        self.__assignments = []

    def find_assignment(self, assignment):
        """
        Cauta assignment-ul dat in lista
        :param assignment: assignment-ul care este cautat
        :type assignment: Assignment
        :return: assignment-ul gasit daca acesta exista, None altfel
        :rtype: Assignment
        """
        for current_assignment in self.__assignments:
            if current_assignment == assignment:
                return current_assignment
        return None

    def add_assignment(self, assignment):
        """
        Adauga assignment-ul dat
        :param assignment: assignment-ul care se adauga
        :type assignment: Assignment
        :return: -; assignment-ul este adaugat la sfarsitul listei de assignment-uri
        :rtype: -;
        :raises: AssignmentAlreadyExistsException daca mai exista un assignment identic
        """
        if self.find_assignment(assignment) is not None:
            raise AssignmentAlreadyExistsException()
        self.__assignments.append(assignment)


    def get_all(self):
        return self.__assignments

    def size(self):
        return len(self.__assignments)


