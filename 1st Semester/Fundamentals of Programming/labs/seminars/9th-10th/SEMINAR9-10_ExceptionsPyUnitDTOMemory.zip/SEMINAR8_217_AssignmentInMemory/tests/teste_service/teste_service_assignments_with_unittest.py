import unittest

from domain.dtos import PersonAssignments
from domain.validators import PersonValidator, AssignmentValidator
from exceptions.exceptions import AssignmentAlreadyExistsException, PersonDoesNotExistException, \
    TaskDoesNotExistException, ValidationException
from repository.assignment_repository import AssignmentInMemoryRepository
from repository.person_repository import PersonInMemoryRepository, PersonFileRepository
from repository.task_repository import TaskFileRepository
from service.assignment_service import AssignmentController
from utils.file_utils import copy_file_content, clear_file_content


class TestsAssignmentService(unittest.TestCase):
    def setUp(self):
        clear_file_content('test_tasks.txt')
        copy_file_content('default_tasks.txt', 'test_tasks.txt')
        task_repo = TaskFileRepository('test_tasks.txt')

        clear_file_content('test_persons.txt')
        copy_file_content('default_persons.txt', 'test_persons.txt')
        person_repo = PersonFileRepository('test_persons.txt')

        assignment_repo = AssignmentInMemoryRepository()
        assignment_validator = AssignmentValidator()
        self.__assignment_service = AssignmentController(task_repo, person_repo, assignment_repo, assignment_validator)

    def test_add_assignment(self):
        self.__assignment_service.create_assignment(1, '6050706437566', 7)
        self.assertEqual(len(self.__assignment_service.get_all()), 1)

        self.__assignment_service.create_assignment(1, '1760920213245', 7)
        self.assertEqual(len(self.__assignment_service.get_all()), 2)
        self.assertRaises(AssignmentAlreadyExistsException, self.__assignment_service.create_assignment, 1,
                          '1760920213245', 7)
        self.assertRaises(PersonDoesNotExistException, self.__assignment_service.create_assignment, 1, '1760920213241',
                          5)
        self.assertRaises(TaskDoesNotExistException, self.__assignment_service.create_assignment, 1347, '6050706437566',
                          5)
        self.assertRaises(ValidationException, self.__assignment_service.create_assignment, 8, '1760920213245', 100)

    def test_busiest_people_report(self):
        # all ok, can add
        self.__assignment_service.create_assignment(1, '6050706437566', 7)
        self.__assignment_service.create_assignment(2, '6050706437566', 8)
        self.__assignment_service.create_assignment(10, '6050706437566', 9)
        self.__assignment_service.create_assignment(4, '6050706437566', 10)
        self.__assignment_service.create_assignment(5, '6050706437566', 5)

        self.__assignment_service.create_assignment(1, '5040703757453', 7)
        self.__assignment_service.create_assignment(2, '5040703757453', 8)
        self.__assignment_service.create_assignment(10, '5040703757453', 9)
        self.__assignment_service.create_assignment(4, '5040703757453', 10)
        self.__assignment_service.create_assignment(5, '5040703757453', 5)
        self.__assignment_service.create_assignment(8, '5040703757453', 5)
        self.__assignment_service.create_assignment(9, '5040703757453', 5)

        self.__assignment_service.create_assignment(1, '1760920213245', 3)
        self.__assignment_service.create_assignment(8, '1760920213245', 5)

        self.__assignment_service.create_assignment(2, '1991002122222', 3)
        self.__assignment_service.create_assignment(5, '1991002122222', 5)
        self.__assignment_service.create_assignment(6, '1991002122222', 8)

        self.__assignment_service.create_assignment(6, '1681210156348', 8)

        busiest_3_people = self.__assignment_service.get_busiest_people_with_dto(3)
        first_dto = busiest_3_people[0]
        self.assertEqual(first_dto.get_nume(),"Ioana")
        self.assertEqual(first_dto.get_nr_taskuri(),7)

        second_dto = busiest_3_people[1]
        self.assertEqual(second_dto.get_nume(), "Matei")
        self.assertEqual(second_dto.get_nr_taskuri(), 5)

        third_dto = busiest_3_people[2]
        self.assertEqual(third_dto.get_nume(), "Daniel")
        self.assertEqual(third_dto.get_nr_taskuri(), 3)

        # need to decide and test accordingly:
        # --what to do if there aren't enough people (nr_persoane_repo<n dat)
        # --what to do if equality (e.g. in exemplul de mai sus, cum procedam daca o alta persoana avea 3 task-uri?)
