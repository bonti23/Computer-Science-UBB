from domain.assignment import Assignment
from domain.person import Person
from domain.task import Task


def test_create_assignment():
    task = Task(1, 'Decorate for Christmas', 18, 12, 'pending')
    person = Person('2980107123456', 'Alessia')

    assignment = Assignment(task, person, 9.3)

    assert (assignment.get_task() == task)
    assert (assignment.get_person() == person)
    assert (assignment.get_evaluare() == 9.3)


def test_equal_assignment():
    task1 = Task(1, 'Bake gingerbread cookies', 24, 12, 'pending')
    person = Person('2970103123456', 'Marcel')

    assignment1 = Assignment(task1, person, 10)
    assignment2 = Assignment(task1, person, 8.55)
    assert (assignment1 == assignment2)

    task2 = Task(2, 'Buy Christmas presents', 20, 12, 'pending')
    assignment3 = Assignment(task2, person, 3)
    assert (assignment3 != assignment2)
