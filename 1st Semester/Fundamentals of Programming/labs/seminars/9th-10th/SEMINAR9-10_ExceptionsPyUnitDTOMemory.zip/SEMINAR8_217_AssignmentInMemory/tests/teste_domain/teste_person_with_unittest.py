import unittest

from domain.person import Person

class TestPersons(unittest.TestCase):
    
    def test_create_person(self):
        
    
        person = Person('6050706437566', 'Alessia')
        self.assertEqual(person.get_nume() , 'Alessia')
        self.assertEqual(person.get_cnp() , '6050706437566')
        self.assertEqual(person.get_ziua_nasterii() , 6)
        self.assertEqual(person.get_luna_nasterii() , 7)
        self.assertEqual(person.get_anul_nasterii() , 2005)
    
        person = Person('1991002122222', 'Daniel')
        self.assertEqual(person.get_nume() , 'Daniel')
        self.assertEqual(person.get_cnp() , '1991002122222')
        self.assertEqual(person.get_ziua_nasterii() , 2)
        self.assertEqual(person.get_luna_nasterii() , 10)
        self.assertEqual(person.get_anul_nasterii() , 1999)
    
    
    def test_equal_persons(self):
        person1 = Person('6050706437566', 'Alessia')
        person2 = Person('6050706437566', 'Sandra')
        self.assertEqual(person1 , person2)
    
        person1 = Person('6050706437566', 'Alessia')
        person2 = Person('2940706437566', 'Alessia')
        self.assertNotEqual(person1,person2)