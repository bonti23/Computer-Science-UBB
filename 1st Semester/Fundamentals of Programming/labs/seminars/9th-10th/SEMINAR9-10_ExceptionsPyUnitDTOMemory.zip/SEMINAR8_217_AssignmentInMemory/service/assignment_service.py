from collections import defaultdict

from domain.assignment import Assignment
from domain.dtos import PersonAssignments
from exceptions.exceptions import PersonDoesNotExistException, TaskDoesNotExistException


class AssignmentController:
    def __init__(self, task_repo, person_repo, assignment_repo, assignment_validator):
        self.__task_repo = task_repo
        self.__person_repo = person_repo
        self.__assignment_repo = assignment_repo
        self.__assignment_validator = assignment_validator

    def create_assignment(self, id_task, cnp, nota_evaluare):
        """
        Adauga un assignment
        :param id_task: id-ul task-ului din assignment
        :type id_task: int
        :param cnp: cnp-ul persoanei din assignment
        :type cnp: str
        :param nota_evaluare: nota data de persoana assignment-ului
        :type nota_evaluare: float
        :return: -;
        :rtype: -;
        :raises: TaskDoesNotExistException daca nu exista task cu id dat
                 PersonDoesNotExistException daca nu exista persoana cu CNP dat
                 ValidationException daca nota evaluarii nu este valida
                 AssignmentAlreadyExistsException daca exista deja assignment cu task si persoana data
        """

        task = self.__task_repo.find(id_task)
        #maybe throw exception from find
        if task is None:
            raise TaskDoesNotExistException()

        person = self.__person_repo.find(cnp)
        if person is None:
            raise PersonDoesNotExistException()

        assignment = Assignment(task, person, nota_evaluare)
        self.__assignment_validator.validate(assignment)

        self.__assignment_repo.add_assignment(assignment)

    def get_all(self):
        return self.__assignment_repo.get_all()

    def get_busiest_people_with_dto(self, n: int):
        """
        Returneaza primele n persoane cu cele mai multe task-uri atribuite
        :param n: numarul de persoane
        :type n: int
        :return: lista de dictionare care contin informatiile necesare
        :rtype: list
        """

        assignments = self.__assignment_repo.get_all()

        # people_dict: cheie = cnp; valoare = obiect DTO
        people_dict = {}
        for assignment in assignments:
            current_cnp = assignment.get_person().get_cnp()
            if current_cnp in people_dict:
                people_dict[current_cnp].increase_nr_taskuri()
            else:
                people_dict[current_cnp] = PersonAssignments(assignment.get_person().get_nume())

        # lista de obiecte DTO
        dto_list = people_dict.values()
        dto_list = sorted(dto_list, key=lambda item: item.get_nr_taskuri(), reverse=True)

        busiest_n_people = dto_list[:n]
        return busiest_n_people


    def sort_by_fun(self):
        """
        Returneaza o lista sortata cu informatii despre task-uri si media evaluarii lor
        :return: list
        :rtype:
        """
        pass
