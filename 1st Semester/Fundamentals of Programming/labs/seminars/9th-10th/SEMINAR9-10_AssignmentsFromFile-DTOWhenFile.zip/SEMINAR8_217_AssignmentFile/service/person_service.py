from domain.person import Person
from domain.validators import PersonValidator
from repository.person_repository import PersonInMemoryRepository


class PersonController:
    def __init__(self, repository, person_validator: PersonValidator):
        self.__person_validator = person_validator
        self.__repo = repository

    def add_person(self, cnp: str, nume: str) -> None:
        """
        Adauga o persoana
        :param cnp: cnp-ul persoanei de adaugat
        :type cnp: str
        :param nume: numele persoanei de adaugat
        :type nume: str
        :return: -;
        :rtype:
        :raises: ValueError daca datele persoanei sunt invalide, daca persoana cu cnp exista deja
        """
        person = Person(cnp, nume)
        self.__person_validator.validate_person(person)
        self.__repo.store(person)

    def delete_person(self, cnp: str):
        """
        Sterge persoana dupa cnp
        :param cnp: cnp-ul dupa care se sterge
        :type cnp: str
        :return: persoana stearsa
        :rtype: Person
        :raises: ValueError daca nu exista persoana cu cnp dat
        """

        return self.__repo.delete(cnp)

    def get_all_persons(self) -> list:
        """
        Returneaza lista cu toate persoanele

        """
        return self.__repo.get_all()

    def update_person(self, cnp, nume):
        """
        Modifica datele persoanei cu CNP cnp
        :param cnp: cnp-ul persoanei pe care vrem sa o modificam
        :type cnp: str
        :param nume: noul nume al persoanei
        :type nume: str
        :return: -;
        :rtype:
        :raises ValueError daca persoana modificata nu are date corecte, nu exista persoana cu cnp dat,
        """
        modified_person = Person(cnp, nume)
        self.__person_validator.validate_person(modified_person)
        self.__repo.update(cnp, modified_person)

    def find_person(self, cnp):
        """
        Cauta persoana cu CNP dat

        :param cnp: CNP-ul persoanei
        :type cnp: str
        :return: persoana cautata daca aceasta exista, None altfel
        :rtype: Person
        """
        return self.__repo.find(cnp)
