from collections import defaultdict

from domain.assignment import Assignment
from domain.dtos import PersonAssignments


class AssignmentController:
    def __init__(self, task_repo, person_repo, assignment_repo, assignment_validator):
        self.__task_repo = task_repo
        self.__person_repo = person_repo
        self.__assignment_repo = assignment_repo
        self.__assignment_validator = assignment_validator

    def create_assignment(self, id_task, cnp, nota_evaluare):
        """
        Adauga un assignment
        :param id_task: id-ul task-ului din assignment
        :type id_task: int
        :param cnp: cnp-ul persoanei din assignment
        :type cnp: str
        :param nota_evaluare: nota data de persoana assignment-ului
        :type nota_evaluare: float
        :return: -;
        :rtype: -;
        :raises: ValueError daca nu exista task cu id dat
                            daca nu exista persoana cu CNP dat
                            daca nota evaluarii nu este valida
                            daca exista deja assignment cu task si persoana data
        """

        task = self.__task_repo.find(id_task)
        if task is None:
            raise ValueError("Nu exista task cu id dat.")

        person = self.__person_repo.find(cnp)
        if person is None:
            raise ValueError("Nu exista persoana cu CNP dat.")

        assignment = Assignment(id_task, cnp, nota_evaluare)
        self.__assignment_validator.validate(assignment)

        self.__assignment_repo.add_assignment(assignment)

    def get_all(self):
        return self.__assignment_repo.get_all()

    def get_busiest_people(self, n: int):
        """
        Returneaza primele n persoane cu cele mai multe task-uri atribuite
        :param n: numarul de persoane
        :type n: int
        :return: lista de DTOs care contin informatiile necesare
        :rtype: list
        """

        dto_list = self.__assignment_repo.get_people_assignment_stats()
        # lista de obiecte DTO
        dto_list = sorted(dto_list, key=lambda item: item.get_nr_taskuri(), reverse=True)

        busiest_n_people = dto_list[:n]
        for person_dto in busiest_n_people:
            cnp = person_dto.get_cnp()
            person_obj = self.__person_repo.find(cnp)
            person_dto.set_nume(person_obj.get_nume())
        return busiest_n_people

    def sort_by_fun(self):
        """
        Returneaza o lista sortata cu informatii despre task-uri si media evaluarii lor
        :return: list
        :rtype:
        """
        pass
