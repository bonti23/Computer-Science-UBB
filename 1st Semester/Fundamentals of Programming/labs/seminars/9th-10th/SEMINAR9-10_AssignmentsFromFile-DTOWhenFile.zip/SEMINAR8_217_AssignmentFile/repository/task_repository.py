from domain.task import Task


class TaskInMemoryRepository:
    def __init__(self):
        self.__task_list = []

    def store(self, task: Task):
        """
        Adauga un task in lista de task-uri
        :param task: task-ul de adaugat
        :type task: Task
        :return: -; lista de task-uri se modifica prin adaugarea la sfarsit a task-ului dat
        :rtype: -;
        :raises: ValueError daca exista deja task cu id-ul dat
        """

        # verificam daca task-ul exista deja -
        # dar definim ce inseamna ca exista deja: are acelasi id, are aceeasi descriere si date, etc...
        # In aceasta varianta: egalitate inseamna ca 2 task-uri au acelasi id
        if self.find(task.get_id()):
            raise ValueError("Exista deja task cu acest id.")
        self.__task_list.append(task)

    def find(self, id):
        """
        Gaseste task-ul cu id dat
        :param id: id-ul cautat
        :type id: int
        :return: task-ul cu id dat
        :rtype: Task
        """
        for task in self.__task_list:
            if task.get_id() == id:
                return task
        return None

    def update(self, id, modified_task):
        """
        Modifica un task dat
        :param id: id-ul task-ului care se modifica
        :type id: int
        :param modified_task: task-ul care contine datele modificate
        :type modified_task: Task
        :return: task-ul modificat
        :rtype: Task
        """
        # TO-DO: How to implement update?
        pass

    def delete(self, id):
        """
        Sterge task cu id dat
        :param id: id-ul dupa care se sterge
        :type id: int
        :return: task-ul sters
        :rtype:Task
        """

        task_to_delete = self.find(id)
        if task_to_delete is None:
            raise ValueError("Nu exista task cu id dat.")

        self.__task_list.remove(task_to_delete)
        return task_to_delete

    def get_all(self) -> list:
        """
        Returneaza intreaga lista de task-uri
        """
        return self.__task_list

    def size(self):
        return len(self.__task_list)

    # Extra-function
    def delete_multiple(self, filter_function):
        """
        Elimina task-uri pe baza unui anumit criteriu
        :param filter_function: functia dupa care se filtreaza
        :type filter_function: function
        :return: numarul de task-uri sterse
        :rtype: int
        """
        initial_no_tasks = self.size()
        self.__task_list = [task for task in self.__task_list if not filter_function(task)]
        return initial_no_tasks - self.size()


class TaskFileRepository:
    """
    Repository care gestioneaza date din fisier
    """

    def __init__(self, filename):
        self.__filename = filename

    def read_from_file(self):
        f = open(self.__filename, mode='r')

        tasks = []
        lines = f.readlines()
        for line in lines:
            elements = line.split(',')
            elements = [element.strip() for element in elements]
            id = int(elements[0])
            descriere = elements[1]
            zi = int(elements[2])
            luna = int(elements[3])
            status = elements[4]
            task = Task(id, descriere, zi, luna, status)
            tasks.append(task)
        f.close()
        return tasks

    def write_to_file(self, task_list):
        with open(self.__filename, mode='w') as f:
            for task in task_list:
                task_elements = [task.get_id(), task.get_descriere(), task.get_zi_deadline(), task.get_luna_deadline(),
                                 task.get_status()]
                task_elements = [str(element) for element in task_elements]
                line = ', '.join(task_elements) + '\n'
                f.write(line)

    def store(self, task):
        if self.find(task.get_id()) is not None:
            raise ValueError("Exista deja task-ul cu id dat.")

        tasks = self.read_from_file()
        tasks.append(task)
        self.write_to_file(tasks)

    def find(self, id):
        """
        Gaseste task-ul cu id dat
        :param id: id-ul cautat
        :type id: int
        :return: task-ul cu id dat
        :rtype: Task
        """
        tasks = self.read_from_file()
        for task in tasks:
            if task.get_id() == id:
                return task
        return None


    def delete(self, id):
        """
        Sterge task cu id dat
        :param id: id-ul dupa care se sterge
        :type id: int
        :return: task-ul sters
        :rtype:Task
        """
        tasks = self.read_from_file()
        task_to_delete = self.find(id)
        if task_to_delete is None:
            raise ValueError("Nu exista task cu id dat.")

        tasks.remove(task_to_delete)
        self.write_to_file(tasks)
        return task_to_delete

    def get_all(self) -> list:
        """
        Returneaza intreaga lista de task-uri
        """
        return self.read_from_file()

    def size(self):
        return len(self.read_from_file())

