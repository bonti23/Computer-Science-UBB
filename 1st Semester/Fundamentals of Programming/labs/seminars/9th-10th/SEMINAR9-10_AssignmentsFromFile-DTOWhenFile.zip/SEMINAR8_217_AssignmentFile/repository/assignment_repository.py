from domain.assignment import Assignment
from domain.dtos import PersonAssignments


class AssignmentInMemoryRepository:
    def __init__(self):
        print('Constructor of AssignmentMemoryRepo called.')
        self.__assignments = []

    def find_assignment(self, assignment):
        """
        Cauta assignment-ul dat in lista
        :param assignment: assignment-ul care este cautat
        :type assignment: Assignment
        :return: assignment-ul gasit daca acesta exista, None altfel
        :rtype: Assignment
        """
        for current_assignment in self.__assignments:
            if current_assignment == assignment:
                return current_assignment
        return None

    def add_assignment(self, assignment):
        """
        Adauga assignment-ul dat
        :param assignment: assignment-ul care se adauga
        :type assignment: Assignment
        :return: -; assignment-ul este adaugat la sfarsitul listei de assignment-uri
        :rtype: -;
        :raises: ValueError daca mai exista un assignment identic
        """
        if self.find_assignment(assignment) is not None:
            raise ValueError("Exista deja acest assignment.")
        self.__assignments.append(assignment)

    def get_all(self):
        return self.__assignments

    def size(self):
        return len(self.__assignments)


class AssignmentFileRepository(AssignmentInMemoryRepository):
    def __init__(self, filename):
        super().__init__()
        self.__filename = filename
        self.read_from_file()

    def read_from_file(self):
        """
        Citeste assignment-urile din fisier
        :return: -; incarca assignment-urile
        """
        with open(self.__filename, 'r') as assignments_file:
            lines = assignments_file.readlines()
            lines = [line.strip() for line in lines if line.strip()!='']
            for line in lines:
                cnp, id_task, evaluare = line.split(',')
                id_task = int(id_task)
                evaluare = float(evaluare)
                assignment = Assignment( id_task, cnp.strip(), evaluare)
                super().add_assignment(assignment)

    def write_to_file(self):
        """
        Salveaza in fisier assignment-urile curente
        """
        assignments = super().get_all()
        with open(self.__filename, 'w') as assignments_file:
            for assignment in assignments:
                line_to_write = str(assignment.get_person_cnp()) + ',' + str(assignment.get_task_id()) + ',' + str(
                    str(assignment.get_evaluare()) + '\n')
                assignments_file.write(line_to_write)

    def add_assignment(self, assignment):
        """
        Adauga assignment-ul
        :param assignment: assignment de adaugat
        :type assignment: Assignment
        :return: -; assignment-ul este adaugat la sfarsitul listei de assignments
        """
        super().add_assignment(assignment)
        self.write_to_file()

    def get_people_assignment_stats(self):
        """
        Return assignments
        :param person_cnp:
        :type person_cnp:
        :return:
        :rtype:
        """
        people_dict = {}
        assignments = self.get_all()
        for assignment in assignments:
            current_cnp = assignment.get_person_cnp()
            if current_cnp in people_dict:
                people_dict[current_cnp].increase_nr_taskuri()
            else:
                people_dict[current_cnp] = PersonAssignments(assignment.get_person_cnp())

        return people_dict.values()
