from domain.person import Person
from domain.task import Task


class Assignment:

    def __init__(self, task_id, person_cnp, eval):
        #Daca citim din fisier, citim doar id-uri, CNP-uri
        self.__task_id = task_id
        self.__person_cnp = person_cnp
        self.__eval = eval

    def get_task_id(self):
        return self.__task_id

    def get_person_cnp(self):
        return self.__person_cnp

    def get_evaluare(self):
        return self.__eval

    def __eq__(self, other):
        return self.__task_id == other.get_task_id() and self.__person_cnp == other.get_person_cnp()

    def __str__(self):
        return 'ID task: '+str(self.__task_id)+ ' | CNP Persoana: ' + str(self.__person_cnp)+ ' | Evaluare: ' +str(self.__eval)

