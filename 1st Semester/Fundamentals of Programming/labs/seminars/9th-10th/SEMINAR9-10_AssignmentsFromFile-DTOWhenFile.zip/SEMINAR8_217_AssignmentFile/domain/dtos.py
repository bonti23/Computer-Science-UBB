class PersonAssignments:
    def __init__(self, cnp):
        self.__cnp = cnp
        self.__nume = ""
        self.__nr_taskuri = 1

    def get_nume(self):
        return self.__nume
    def set_nume(self, nume):
        self.__nume = nume
    def get_cnp(self):
        return self.__cnp
    def get_nr_taskuri(self):
        return self.__nr_taskuri

    def increase_nr_taskuri(self):
        self.__nr_taskuri += 1

    def __str__(self):
        return "Persoana cu nume: " + str(self.__nume) + " are atribuite " + str(self.__nr_taskuri) + ' taskuri.'
