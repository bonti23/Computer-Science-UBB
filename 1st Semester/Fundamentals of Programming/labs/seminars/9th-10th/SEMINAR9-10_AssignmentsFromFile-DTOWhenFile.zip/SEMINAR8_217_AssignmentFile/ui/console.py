from colorama import Fore, Style

from service.assignment_service import AssignmentController
from service.person_service import PersonController
from service.task_service import TaskController


class Console:
    def __init__(self, task_controller: TaskController, person_controller: PersonController,
                 assignment_controller: AssignmentController):
        self.__task_service = task_controller
        self.__person_service = person_controller
        self.__assignment_service = assignment_controller

    def __print_available_commands(self):
        print("Pentru seminar 8 avem la dispozitie urmatoarele functionalitati, accesate prin comenzi:")

        print(Fore.MAGENTA + 'add_task.' + Style.RESET_ALL + ' Adaugare task')
        print(Fore.MAGENTA + 'del_task.' + Style.RESET_ALL + ' Stergere task')
        print(Fore.MAGENTA + 'del_tasks_status.' + Style.RESET_ALL + ' Eliminare task-uri dupa status')

        print(Fore.MAGENTA + 'add_person.' + Style.RESET_ALL + ' Adaugare persoana')
        print(Fore.MAGENTA + 'del_person.' + Style.RESET_ALL + ' Stergere persoana')
        print(Fore.MAGENTA + 'update_person.' + Style.RESET_ALL + ' Modificare nume persoana')

        print(Fore.MAGENTA + 'add_assignment.' + Style.RESET_ALL + ' Creare assignment')

        # Functionalitati de filtrare, rapoarte pentru 1 singura entitate (task-uri)
        print(Fore.GREEN + 'filter_by_deadline.' + Style.RESET_ALL + ' Cautare task cu deadline intre 2 date')
        print(
            Fore.GREEN + 'filter_by_description.' + Style.RESET_ALL + ' Afisare task-uri carre contin in descriere string')
        print(Fore.GREEN + 'by_date_report.' + Style.RESET_ALL + ' Afisare raport pe luna')

        # functionalitati rapoarte cu clasa de legatura
        print(
            Fore.CYAN + 'print_busiest.' + Style.RESET_ALL + ' Afisare primele 3 persoane cu cele mai multe task-uri atribuite.')
        print(
            Fore.CYAN + 'print_most_fun.' + Style.RESET_ALL + ' Afisare task-uri cu cele mai bune evaluari (in medie) in ordine descrescatoare.')

        # Functionalitati utile care nu apar in mod explicit in cerinta
        print(Fore.BLUE + 'print_tasks.' + Style.RESET_ALL + ' Afisarea tuturor task-urilor')
        print(Fore.BLUE + 'print_persons.' + Style.RESET_ALL + ' Afisarea tuturor persoanelor')
        print(Fore.BLUE + 'print_assignments.' + Style.RESET_ALL + ' Afisarea tuturor assignment-urilor')

        print(Fore.BLUE + 'add_default_tasks.' + Style.RESET_ALL + ' Adaugare task-uri default')
        print(Fore.RED + 'exit.' + Style.RESET_ALL + ' Iesire')

    def print_entity_list(self, entity_list):
        for entity in entity_list:
            print(entity)

    def delete_task_by_id_ui(self):
        try:
            id = int(input("Introuduceti id dupa care se sterge:"))
            deleted_task = self.__task_service.delete_task(id)
            print(Fore.GREEN + "SUCCES: " + Style.RESET_ALL + 'Stergere efectuata cu succes:')
            print('Task-ul', str(deleted_task), 's-a sters cu succes.')

        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def add_task_ui(self):
        id = input("Introduceti id:")
        descriere = input("Introduceti descrierea:")
        data = input("Introduceti data:")
        status = input("Introduceti status:")
        try:
            id = int(id)
            zi, luna = data.split('-')
            zi = int(zi)
            luna = int(luna)
            self.__task_service.add_task(id, descriere, zi, luna, status)
            print(Fore.GREEN + 'SUCCES: ' + Style.RESET_ALL + 'Adaugarea fost efectuata cu succes.')

        except ValueError as e:
            print(Fore.RED + 'EROARE:' + str(e) + Style.RESET_ALL)

    def delete_task_by_status_ui(self):
        status = input("Introduceti statusul dupa care se sterge:")

        number_of_deleted_tasks = self.__task_service.delete_by_status(status)
        print("S-au sters " +
              Fore.YELLOW + str(
            number_of_deleted_tasks) + Style.RESET_ALL + " task-uri cu status-ul " + Fore.BLUE + status + Style.RESET_ALL)

    def search_task_ui(self):

        print('Introduceti datele:')
        try:
            zi_start = int(input('Zi start:'))
            luna_start = int(input('Luna start:'))
            zi_finish = int(input('Zi finish:'))
            luna_finish = int(input('Luna finish:'))

            lista_taskuri_intre_date = self.__task_service.filter_by_date(zi_start, luna_start, zi_finish, luna_finish)
            if len(lista_taskuri_intre_date) > 0:
                print('Exista task intre datele date. Task-urile gasite sunt:')
                self.print_entity_list(lista_taskuri_intre_date)
            else:
                print(Fore.MAGENTA + "Nu exista task intre datele date." + Style.RESET_ALL)

        except ValueError:
            print(Fore.RED + 'EROARE: Introduceti numere pentru date.' + Style.RESET_ALL)

    def filter_tasks_by_description_ui(self):
        descriere_substr = input('Introduceti parte din descriere:')
        filtered_tasks = self.__task_service.filter_by_description(descriere_substr)

        if len(filtered_tasks) > 0:
            print('Task-urile care contin in descriere textul dat sunt:')
            self.print_entity_list(filtered_tasks)
        else:
            print(Fore.MAGENTA + "Nu exista task-uri pentru care descrierea contine string-ul dat." + Style.RESET_ALL)

    def show_task_report_ui(self):
        report = self.__task_service.get_report_by_day()
        # report is a dict
        for day, tasks in report.items():
            print('Ziua:', day)
            self.print_entity_list(tasks)

    def add_default_tasks_ui(self):
        try:
            self.__task_service.add_default_tasks()
            print(
                Fore.GREEN + 'SUCCES: ' + Style.RESET_ALL + 'Adaugarea task-urilor default a fost efectuata cu succes.')
        except ValueError:
            print(
                Fore.RED + 'ERROR: ' + Style.RESET_ALL + 'Adaugarea task-urilor default a esuat. Cel mai probabil au mai fost adaugate o data.')

    def add_person_ui(self):
        print('Introduceti datele persoanei.')
        cnp = input('CNP:')
        nume = input('Nume')
        try:
            self.__person_service.add_person(cnp, nume)
            print(Fore.GREEN + 'SUCCES: ' + Style.RESET_ALL + 'Adaugarea fost efectuata cu succes.')
        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def delete_person_ui(self):
        print('Introduceti CNP-ul persoanei.')
        cnp = input('CNP:')
        try:
            self.__person_service.delete_person(cnp)
            print(Fore.GREEN + 'SUCCES: ' + Style.RESET_ALL + 'Stergerea fost efectuata cu succes.')
        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def update_person_ui(self):
        print('Va rugam introduceti datele persoanei pe care doriti sa o modificati.')
        cnp = input('CNP:')
        nume = input('Noul nume')
        try:
            self.__person_service.update_person(cnp, nume)
            print(Fore.GREEN + 'SUCCES: ' + Style.RESET_ALL + 'Modificarea fost efectuata cu succes.')
        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def add_assignment_ui(self):
        id_task = input("Introduceti id-ul task-ului:")
        cnp_persoana = input("Introduceti CNP persoana:")
        evaluare = input("Introduceti evaluarea task-ului:")

        try:
            id_task = int(id_task)
            evaluare = float(evaluare)
            self.__assignment_service.create_assignment(id_task, cnp_persoana, evaluare)
        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def print_busiest_people(self):
        number_of_people = input("Numarul de persoane:")
        try:
            number_of_people = int(number_of_people)
            list_of_people = self.__assignment_service.get_busiest_people(number_of_people)
            self.print_entity_list(list_of_people)

        except ValueError as e:
            print(Fore.RED + "EROARE: " + Style.RESET_ALL + str(e))

    def print_sorted_by_fun(self):
        sorted_tasks = self.__assignment_service.sort_by_fun()

    def run(self):
        self.__print_available_commands()
        while True:
            option = input('>').lower().strip()
            if option == 'help':
                self.__print_available_commands()
            if option == "print_tasks":
                self.print_entity_list(self.__task_service.get_all_tasks())
            elif option == 'print_persons':
                self.print_entity_list(self.__person_service.get_all_persons())
            elif option == 'print_assignments':
                self.print_entity_list(self.__assignment_service.get_all())
            elif option == 'add_default_tasks':
                self.add_default_tasks_ui()
            elif option == 'add_task':
                self.add_task_ui()
            elif option == 'del_task':
                self.delete_task_by_id_ui()
            elif option == 'del_tasks_status':
                self.delete_task_by_status_ui()

            elif option == 'add_person':
                self.add_person_ui()
            elif option == 'del_person':
                self.delete_person_ui()
            elif option == 'update_person':
                self.update_person_ui()

            elif option == 'add_assignment':
                self.add_assignment_ui()

            elif option == 'filter_by_deadline':
                self.search_task_ui()
            elif option == 'filter_by_description':
                self.filter_tasks_by_description_ui()
            elif option == 'by_date_report':
                self.show_task_report_ui()

            elif option == 'print_busiest':
                self.print_busiest_people()
            elif option == 'print_most_fun':
                self.print_sorted_by_fun()
            elif option == "exit":
                break
            else:
                print("Invalid option.")
