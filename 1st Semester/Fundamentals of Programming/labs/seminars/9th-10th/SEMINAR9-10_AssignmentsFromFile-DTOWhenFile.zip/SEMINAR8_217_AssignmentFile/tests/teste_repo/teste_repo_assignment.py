from domain.assignment import Assignment
from domain.person import Person
from domain.task import Task
from repository.assignment_repository import AssignmentInMemoryRepository


def test_add_assignment():
    test_repo = AssignmentInMemoryRepository()
    task1 = Task(3, "Make gingerbread", 20, 12, 'in-progress')
    person1 = Person('1910918123456', "Mircea")
    assignment = Assignment(task1, person1, 9.25)

    assert (test_repo.size() == 0)
    test_repo.add_assignment(assignment)
    assert (test_repo.size() == 1)

    try:
        test_repo.add_assignment(assignment)
        assert False
    except ValueError:
        assert True

    task2 = Task(2, "Watch a Christmas movie", 27, 12, 'pending')
    assignment2 = Assignment(task2, person1, 8.9)
    test_repo.add_assignment(assignment2)
    assert (test_repo.size() == 2)

    person2 = Person('1870624123456','Andra')
    assignment3 = Assignment(task1, person2, 10)
    test_repo.add_assignment(assignment3)
    assert (test_repo.size() == 3)

def test_find_assignment():
    test_repo = AssignmentInMemoryRepository()
    task1 = Task(3, "Make gingerbread", 20, 12, 'in-progress')
    task2 = Task(2, "Watch a Christmas movie", 27, 12, 'pending')

    person1 = Person('1910918123456', "Mircea")
    person2 = Person('1870624123456','Andra')

    assignment1 = Assignment(task1, person1, 9.25)
    assignment2 = Assignment(task2, person1, 8.9)
    assignment3 = Assignment(task1, person2, 10)
    assignment4 = Assignment(task2, person2, 10)

    assert (test_repo.size() == 0)
    test_repo.add_assignment(assignment1)
    test_repo.add_assignment(assignment2)
    test_repo.add_assignment(assignment3)
    assert (test_repo.size() == 3)

    assert (test_repo.find_assignment(assignment1) is not None)
    assert (test_repo.find_assignment(assignment2) is not None)
    assert (test_repo.find_assignment(assignment3) is not None)
    assert (test_repo.find_assignment(assignment4) is None)


