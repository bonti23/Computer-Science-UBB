from domain.person import Person
from repository.person_repository import PersonInMemoryRepository, PersonFileRepository
from utils.file_utils import copy_file_content, clear_file_content


def test_add_repo():
    test_repo = PersonInMemoryRepository()
    assert (test_repo.size() == 0)

    person = Person('2930918123456', "Maria")
    test_repo.store(person)
    assert (test_repo.size() == 1)

    try:
        test_repo.store(person)
        assert False
    except ValueError:
        assert True

    person2 = Person('1930918123456','Matei')
    test_repo.store(person2)
    assert (test_repo.size() == 2)


def test_find_repo():
    test_repo = PersonInMemoryRepository()
    assert (test_repo.size() == 0)

    person1 = Person('1910918123456', "Mircea")
    person2 = Person('2920918123456', "Carina")
    person3 = Person('5930918123456', "Alex")

    test_repo.store(person1)
    test_repo.store(person2)
    test_repo.store(person3)

    assert (test_repo.size() == 3)

    assert (test_repo.find('1910918123456') is not None)
    assert (test_repo.find('2920918123456') is not None)
    assert (test_repo.find('5930918123456') is not None)
    assert (test_repo.find('6931118123456') is None)


def test_delete_repo():
    test_repo = PersonInMemoryRepository()
    person1 = Person('1910918123456', "Mircea")
    person2 = Person('2920918123456', "Carina")
    person3 = Person('5930918123456', "Alex")


    test_repo.store(person1)
    test_repo.store(person2)
    test_repo.store(person3)
    assert (test_repo.size() == 3)

    deleted_person = test_repo.delete('1910918123456')
    assert (test_repo.size() == 2)
    assert (test_repo.find('1910918123456') is None)
    assert (deleted_person.get_nume() == "Mircea")

    deleted_person = test_repo.delete('5930918123456')
    assert (test_repo.size() == 1)
    assert (not test_repo.find('5930918123456'))
    assert (deleted_person.get_nume() == "Alex")

    test_repo.store(Person('5930918123456','Alexis'))
    assert (test_repo.size() == 2)

    deleted_person = test_repo.delete('5930918123456')
    assert (test_repo.size() == 1)
    assert (test_repo.find('5930918123456') is None)
    assert (deleted_person.get_nume() == "Alexis")

    try:
        test_repo.delete('5930918123451')
        assert False
    except ValueError:
        assert True


def test_read_from_file():
    clear_file_content('test_persons.txt')
    copy_file_content("default_persons.txt", 'test_persons.txt')
    test_repo = PersonFileRepository("test_persons.txt")
    assert (test_repo.size() == 7)


def test_store_repo_file():
    clear_file_content('test_persons.txt')
    test_repo = PersonFileRepository("test_persons.txt")

    person = Person('1730523123456', 'Marcel')
    test_repo.store(person)
    assert (test_repo.size() == 1)

    try:
        test_repo.store(person)
        assert False
    except ValueError:
        assert True

    person2 = Person('1710523123456', 'Marcel')
    test_repo.store(person2)
    assert (test_repo.size() == 2)


def test_find_repo_file():
    clear_file_content('test_persons.txt')
    test_repo = PersonFileRepository("test_persons.txt")

    assert (test_repo.size() == 0)

    person1 = Person('1910918123456', "Mircea")
    person2 = Person('2920918123456', "Carina")
    person3 = Person('5930918123456', "Alex")

    test_repo.store(person1)
    test_repo.store(person2)
    test_repo.store(person3)

    assert (test_repo.size() == 3)

    assert (test_repo.find('1910918123456') is not None)
    assert (test_repo.find('2920918123456') is not None)
    assert (test_repo.find('5930918123456') is not None)
    assert (test_repo.find('6931118123456') is None)



def test_delete_repo_file():
    clear_file_content('test_persons.txt')
    test_repo = PersonFileRepository("test_persons.txt")
    person1 = Person('1910918123456', "Mircea")
    person2 = Person('2920918123456', "Carina")
    person3 = Person('5930918123456', "Alex")

    test_repo.store(person1)
    test_repo.store(person2)
    test_repo.store(person3)
    assert (test_repo.size() == 3)

    deleted_person = test_repo.delete('1910918123456')
    assert (test_repo.size() == 2)
    assert (test_repo.find('1910918123456') is None)
    assert (deleted_person.get_nume() == "Mircea")

    deleted_person = test_repo.delete('5930918123456')
    assert (test_repo.size() == 1)
    assert (not test_repo.find('5930918123456'))
    assert (deleted_person.get_nume() == "Alex")

    test_repo.store(Person('5930918123456', 'Alexis'))
    assert (test_repo.size() == 2)

    deleted_person = test_repo.delete('5930918123456')
    assert (test_repo.size() == 1)
    assert (test_repo.find('5930918123456') is None)
    assert (deleted_person.get_nume() == "Alexis")

    try:
        test_repo.delete('5930918123451')
        assert False
    except ValueError:
        assert True
