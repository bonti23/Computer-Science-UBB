from domain.validators import PersonValidator, AssignmentValidator
from repository.assignment_repository import AssignmentInMemoryRepository, AssignmentFileRepository
from repository.person_repository import PersonInMemoryRepository, PersonFileRepository
from repository.task_repository import TaskFileRepository
from service.assignment_service import AssignmentController
from utils.file_utils import copy_file_content, clear_file_content


def test_add_assignment():
    clear_file_content('test_tasks.txt')
    copy_file_content('default_tasks.txt', 'test_tasks.txt')
    task_repo = TaskFileRepository('test_tasks.txt')

    clear_file_content('test_persons.txt')
    copy_file_content('default_persons.txt', 'test_persons.txt')
    person_repo = PersonFileRepository('test_persons.txt')

    assignment_repo = AssignmentInMemoryRepository()
    assignment_validator = AssignmentValidator()
    assignment_service = AssignmentController(task_repo, person_repo, assignment_repo, assignment_validator)
    # all ok, can add
    assignment_service.create_assignment(1, '6050706437566', 7)
    assert (len(assignment_service.get_all()) == 1)

    assignment_service.create_assignment(1, '1760920213245', 7)
    assert (len(assignment_service.get_all()) == 2)

    # add same assignment
    try:
        assignment_service.create_assignment(1, '1760920213245', 7)
        assert False
    except ValueError:
        assert True

    # person doesn't exist
    try:
        assignment_service.create_assignment(1, '1760920213241', 5)
        assert False
    except ValueError:
        assert True

    # task doesn't exist
    try:
        assignment_service.create_assignment(1347, '1760920213245', 5)
        assert False
    except ValueError:
        assert True

    # incorrect evaluation score
    try:
        assignment_service.create_assignment(1347, '1760920213245', 100)
        assert False
    except ValueError:
        assert True


def test_busiest_people_report():
    clear_file_content('test_tasks.txt')
    copy_file_content('default_tasks.txt', 'test_tasks.txt')
    task_repo = TaskFileRepository('test_tasks.txt')

    clear_file_content('test_persons.txt')
    copy_file_content('default_persons.txt', 'test_persons.txt')
    person_repo = PersonFileRepository('test_persons.txt')

    assignment_repo = AssignmentFileRepository('test_assignments.txt')
    assignment_validator = AssignmentValidator()
    assignment_service = AssignmentController(task_repo, person_repo, assignment_repo, assignment_validator)
    # all ok, can add


    #not ideal that we access fields directly

    busiest_3_people = assignment_service.get_busiest_people(3)
    first_dto = busiest_3_people[0]
    assert (first_dto.get_nume()=="Alex")
    assert (first_dto.get_nr_taskuri()== 5)

    second_dto = busiest_3_people[1]
    assert (second_dto.get_nume()== "Matei")
    assert (second_dto.get_nr_taskuri(), 4)

    third_dto = busiest_3_people[2]
    assert (third_dto.get_nume()=="Maya")
    assert (third_dto.get_nr_taskuri(), 3)

    #need to decide and test accordingly:
    #--what to do if there aren't enough people (nr_persoane_repo<n dat)
    #--what to do if equality (e.g. in exemplul de mai sus, cum procedam daca o alta persoana avea 3 task-uri?)

