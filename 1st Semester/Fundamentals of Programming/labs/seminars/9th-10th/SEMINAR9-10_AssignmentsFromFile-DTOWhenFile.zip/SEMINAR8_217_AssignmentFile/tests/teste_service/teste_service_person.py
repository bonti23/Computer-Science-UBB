from domain.validators import PersonValidator
from repository.person_repository import PersonInMemoryRepository, PersonFileRepository
from service.person_service import PersonController
from utils.file_utils import clear_file_content


def test_add_person():
    test_repo = PersonInMemoryRepository()
    test_validator = PersonValidator()
    test_service = PersonController(test_repo, test_validator)

    test_service.add_person('2810909123456', 'Mara')
    assert (len(test_service.get_all_persons()) == 1)

    try:
        test_service.add_person('110909123456', 'Mara')
        assert False
    except ValueError:
        assert True

    try:
        test_service.add_person('1919909123456', 'Mara')
        assert False
    except ValueError:
        assert True

    try:
        test_service.add_person('1910909123456', '')
        assert False
    except ValueError:
        assert True

    test_service.add_person('1010909123456', 'Matei')
    assert (len(test_service.get_all_persons()) == 2)


def test_delete_person():
    test_repo = PersonInMemoryRepository()
    test_validator = PersonValidator()
    test_service = PersonController(test_repo, test_validator)

    test_service.add_person('2810909123456', 'Mara')
    test_service.add_person('1580909100000', 'Matei')
    test_service.add_person('2410909123456', 'Carmen')

    assert (len(test_service.get_all_persons()) == 3)
    deleted_person = test_service.delete_person('2810909123456')
    assert (len(test_service.get_all_persons()) == 2)
    assert (deleted_person.get_nume() == 'Mara')

    deleted_person = test_service.delete_person('2410909123456')
    assert (len(test_service.get_all_persons()) == 1)
    assert (deleted_person.get_nume() == 'Carmen')

    try:
        deleted_person = test_service.delete_person('2730909123456')
        assert False
    except ValueError:
        assert True


def test_modify_person():
    test_repo = PersonInMemoryRepository()
    test_validator = PersonValidator()
    test_service = PersonController(test_repo, test_validator)

    test_service.add_person('2810909123456', 'Mara')
    test_service.add_person('1580909100000', 'Matei')
    test_service.add_person('2410909123456', 'Carmen')

    assert (len(test_service.get_all_persons()) == 3)
    person_before_modif = test_service.find_person('2810909123456')
    assert(person_before_modif.get_nume()=='Mara')

    test_service.update_person('2810909123456', 'Maya')
    person_after_modif = test_service.find_person('2810909123456')
    assert(person_after_modif.get_nume()=='Maya')

    try:
        test_service.update_person('2810909123458', 'CNP nu exista')
        assert False
    except ValueError:
        assert True




def test_add_person_file():
    clear_file_content('test_persons.txt')
    test_repo = PersonFileRepository('test_persons.txt')
    test_validator = PersonValidator()
    test_service = PersonController(test_repo, test_validator)

    test_service.add_person('2810909123456', 'Mara')
    assert (len(test_service.get_all_persons()) == 1)

    try:
        test_service.add_person('110909123456', 'Mara')
        assert False
    except ValueError:
        assert True

    try:
        test_service.add_person('1919909123456', 'Mara')
        assert False
    except ValueError:
        assert True

    try:
        test_service.add_person('1910909123456', '')
        assert False
    except ValueError:
        assert True

    test_service.add_person('1010909123456', 'Matei')
    assert (len(test_service.get_all_persons()) == 2)


def test_delete_person_file():
    pass


def test_modify_person_file():
    pass
