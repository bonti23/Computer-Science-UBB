from colorama import Fore, Style


def create_task(descriere, zi, luna, status) -> dict:
    """
    Creeaza un task
    :param task_str: string-ul care reprezinta task-ul
    :type task_str: str
    :return: task-ul creat
    :rtype: dict
    """

    task_dict = {'descriere': descriere, 'zi_deadline': zi, 'luna_deadline': luna, 'status': status}
    return task_dict


def get_description(task):
    return task['descriere']


def get_deadline_day(task):
    return task['zi_deadline']


def get_deadline_month(task):
    return task['luna_deadline']


def get_status(task):
    return task['status']


def get_date(task):
    return str(task['zi_deadline']) + '-' + str(task['luna_deadline'])


def to_str(task) -> str:
    return Fore.CYAN + task['descriere']+Fore.BLUE + ' | '+ str(task['zi_deadline']) + '/' + str(task['luna_deadline']) + Fore.MAGENTA +  ' | '+task[
              'status'] +Style.RESET_ALL


def test_create_task():
    task = create_task('BookSkydivingAdventure', 11, 12, 'pending')
    assert (type(task) == dict)
    assert (get_description(task) == "BookSkydivingAdventure")
    assert (get_deadline_day(task) == 11)
    assert (get_deadline_month(task) == 12)
    assert (get_status(task) == 'pending')

