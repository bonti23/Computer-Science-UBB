from colorama import Fore, Style

from domain.task import to_str, create_task
from list_manager.task_manager import add_default_tasks, filter_by_description, delete_by_status, \
    delete_task_by_description, add_task, search_for_task


def print_menu():
    print('1. Adaugare task')
    print('2. Cautare task cu deadline intre 2 date')
    print('3. Stergere task dupa descriere')
    print('4. Eliminare task-uri dupa status')
    print('5. Filtrare: afisare task-uri carre contin in descriere string')
    print('6. Afisare raport pe luna')
    print('7. Undo')
    print('P. Afisarea tuturor task-urilor')
    print('A. Adaugare task-uri default')
    print('E. Iesire')


def print_task_list(task_list):
    for task in task_list:
        print(to_str(task))


def search_task_ui(task_list):
    print('Introduceti datele:')
    try:
        zi_start = int(input('Zi start:'))
        luna_start = int(input('Luna start:'))
        zi_finish = int(input('Zi finish:'))
        luna_finish = int(input('Luna finish:'))
        lista_taskuri_intre_date = search_for_task(task_list, zi_start, luna_start, zi_finish, luna_finish)
        if len(lista_taskuri_intre_date):
            print('Exista task intre datele date. Task-urile gasite sunt:')
            print_task_list(lista_taskuri_intre_date)

        else:
            print('Nu exista task intre datele date.')
    except ValueError:
        print(Fore.RED + 'EROARE: Introduceti numere pentru date.' + Style.RESET_ALL)


def add_task_ui(task_list):
    descriere = input("Introduceti descrierea:")
    data = input("Introduceti data:")
    status = input("Introduceti status:")
    zi, luna = data.split('-')
    try:
        zi = int(zi)
        luna = int(luna)
        task = create_task(descriere, zi, luna, status)
        add_task(task_list, task)
    except ValueError:
        print(Fore.RED + 'EROARE: Data trebuie sa fie formata din numere.' + Style.RESET_ALL)


def delete_by_description_ui(task_list):
    descriere = input("Introduceti descrierea dupa care se sterge:")
    delete_task_by_description(task_list, descriere)
    print("Dupa stergere, lista cu task-uri este:")
    print_task_list(task_list)


def delete_by_status_ui(task_list):
    status = input("Introduceti statusul dupa care se sterge:")
    delete_by_status(task_list, status)
    print("Dupa stergere, lista cu task-uri este:")
    print_task_list(task_list)


def show_report_ui(task_list):
    pass


def undo_ui():
    pass


def filter_by_description_ui(task_list):
    descriere_substr = input('Introduceti parte din descriere:')
    print('Task-urile care contin in descriere textul dat sunt:')
    filtered_tasks = filter_by_description(task_list, descriere_substr)
    print_task_list(filtered_tasks)


def start_program():
    task_list = []
    while True:
        print_menu()
        option = input('>')
        option = option.upper().strip()
        if option == "P":
            print_task_list(task_list)
        elif option == "A":
            add_default_tasks(task_list)
        elif option == '1':
            add_task_ui(task_list)
        elif option == '2':
            search_task_ui(task_list)
        elif option == '3':
            delete_by_description_ui(task_list)
        elif option == '4':
            delete_by_status_ui(task_list)
        elif option == '5':
            filter_by_description_ui(task_list)
        elif option == '6':
            show_report_ui(task_list)
        elif option == '7':
            task_list = undo_ui()
        elif option == "E":
            break
        else:
            print("Invalid option.")
