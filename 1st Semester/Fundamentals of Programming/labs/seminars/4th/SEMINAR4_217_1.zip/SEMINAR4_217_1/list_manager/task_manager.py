from domain.task import create_task, get_description, get_deadline_day, get_deadline_month, get_status


def add_task(task_list: list, task: dict) -> None:
    """
    Adauga un task in lista de task-uri
    :param task_list: lista de task-uri
    :type task_list: list
    :param task: task-ul de adaugat
    :type task: dict
    :return: -; modifica lista prin adaugarea la sfarsit a task-ului
    :rtype:
    """
    task_list.append(task)


def add_default_tasks(task_list):
    task1 = create_task('Read book', 11, 10, 'pending')
    task2 = create_task('Host movie marathon', 5, 8, 'done')
    task3 = create_task('Travel to uncharted island', 10, 1, 'in-progress')
    task4 = create_task('Build treehouse', 12, 9, 'pending')
    task5 = create_task('Learn to ski', 4, 4, 'done')
    task_list.extend([task1, task2, task3, task4, task5])

    # task_list.extend(...) echivalent cu:
    # for task in [task1, task2, task3, task4, task5]:
    #     task_list.append(task)
    #
    # sau:
    # task_list.append(task1)
    # task_list.append(task2)
    # ...


def search_for_task(task_list: list, zi_start: int, luna_start: int, zi_end: int, luna_end: int) -> list:
    """
    Cauta un task cu data intre 2 date date
    :param task_list: lista de task-uri
    :param zi_start: ziua datei de inceput
    :param luna_start: luna datei de inceput
    :param zi_end: ziua datei de sfarsit
    :param luna_end: luna datei de sfarsit
    :return: o noua lista cu task-urile care sunt intre datele date
    """
    # TO-DO: refactor for cleaner version
    # See here some options: https://stackoverflow.com/questions/5464410/how-to-tell-if-a-date-is-between-two-other-dates)

    task_with_date_list = []
    for task in task_list:
        if luna_start < get_deadline_month(task) < luna_end:
            task_with_date_list.append(task)
        elif get_deadline_month(task) == luna_start:
            if luna_start == luna_end:
                if zi_start <= get_deadline_day(task) <= zi_end:
                    task_with_date_list.append(task)
            else:
                if zi_start <= get_deadline_day(task):
                    task_with_date_list.append(task)
        elif get_deadline_month(task) == luna_end:
            if luna_start == luna_end:
                if zi_start <= get_deadline_day(task) <= zi_end:
                    task_with_date_list.append(task)
            else:
                if zi_end >= get_deadline_day(task):
                    task_with_date_list.append(task)

    return task_with_date_list


def delete_task_by_description(task_list: list, description: str):
    """
    Sterge task dupa descriere
    :param task_list: lista de task-uri
    :param description: descrierea dupa care se sterge
    :return: -; lista se modifica prin eliminarea task-ului cu descrierea data
    """
    #Presupunem ca exista doar 1 task cu descrierea data
    index_to_remove = -1
    for i, task in enumerate(task_list):
        if get_description(task) == description:
            index_to_remove = i
            break
    if index_to_remove != -1:
        task_list.pop(index_to_remove)

    # daca returnam lista noua cu task-ul cu descriere data sters
    # return [task for task in task_list if get_descriere_task(task) != description]
    # daca modificam lista, nu returnam nimic


def filter_by_description(task_list: list, description: str) -> list:
    """
    Returneaza lista cu task-urile care contin in descriere un string dat
    :param task_list: lista de task-uri
    :param description: substring-ul dupa care se cauta
    :return: o lista in care se regasesc doar task-urile care au in descriere string-ul dat
    """
    return [task for task in task_list if description.lower() in get_description(task).lower()]


def delete_by_status(task_list: list, status: str) -> None:
    """
    Sterge task-urile din list care au statusul dat
    :param task_list: lista de task-uri
    :param status: statusul dupa care se sterge
    :return: -; lista se modifica prin eliminarea task-urilor cu statusul dat
    """

    # daca returnez o lista noua doar cu task-urile care respecta conditia
    # return [task for task in lst if get_status(task)!=status]

    # daca modific lista
    current_list_length = len(task_list)
    i = 0
    while i < current_list_length:
        task = task_list[i]
        if get_status(task) == status:
            task_list.pop(i)
            current_list_length -= 1
        else:
            i += 1


def test_add():
    test_task_list = []
    task = create_task('HostMovieMarathon', 10, 8, 'pending')
    add_task(test_task_list, task)
    assert (len(test_task_list) == 1)
    assert (get_description(test_task_list[0]) == 'HostMovieMarathon')


def test_search_by_date():
    test_task_list = []
    assert (search_for_task(test_task_list, 5, 5, 10, 8) == [])

    task1 = create_task('HostMovieMarathon', 10, 8, 'pending')
    task2 = create_task('Read Book', 5, 3, 'pending')
    task3 = create_task('Build Treehouse', 1, 10, 'pending')

    add_task(test_task_list, task1)
    add_task(test_task_list, task2)
    add_task(test_task_list, task3)

    # E ok sa testam astfel, stim sigur ca se pastreaza ordinea task-urilor?
    assert (search_for_task(test_task_list, 5, 5, 6, 11) == [task1, task3])

    task4 = create_task('HostMovieMarathon', 5, 8, 'pending')
    add_task(test_task_list, task4)

    assert (search_for_task(test_task_list, 5, 5, 6, 11) == [task1, task3, task4])

    task5 = create_task('HostMovieMarathon', 1, 11, 'pending')
    add_task(test_task_list, task5)

    assert (search_for_task(test_task_list, 5, 5, 6, 11) == [task1, task3, task4, task5])
    assert (search_for_task(test_task_list, 5, 5, 1, 11) == [task1, task3, task4, task5])


def test_delete_task_by_description():
    test_task_list = []
    delete_task_by_description(test_task_list, "Read Book")
    assert (test_task_list == [])

    task1 = create_task('HostMovieMarathon', 10, 8, 'pending')
    task2 = create_task('Read Book', 5, 3, 'pending')
    task3 = create_task('Build Treehouse', 1, 10, 'pending')

    add_task(test_task_list, task1)
    add_task(test_task_list, task2)
    add_task(test_task_list, task3)

    delete_task_by_description(test_task_list, "Read Book")
    assert (len(test_task_list) == 2)
    delete_task_by_description(test_task_list, "Travel")
    assert (len(test_task_list) == 2)


def test_filter_by_description():
    task1 = create_task("Travel to see Grand Canyon", 11, 9, 'pending')
    task2 = create_task("Travel abroad", 10, 5, 'pending')
    task3 = create_task("Try new banana bread recipe", 11, 2, "done")
    task4 = create_task("Host a Halloween party", 31, 10, 'in-progress')
    task5 = create_task("Buy stuff for New Year party", 28, 12, "pending")

    test_list = [task1, task2, task3, task4, task5]
    filtered_by_travel = filter_by_description(test_list, 'travel')
    assert (len(filtered_by_travel) == 2)
    assert (len(test_list) == 5)

    filtered_by_recipe = filter_by_description(test_list, 'recipe')
    assert (len(filtered_by_recipe) == 1)
    assert (len(test_list) == 5)

    filtered_by_cook = filter_by_description(test_list, 'cook')
    assert (len(filtered_by_cook) == 0)
    assert (len(test_list) == 5)


def test_delete_by_status():
    test_list = []

    delete_by_status(test_list, 'pending')
    assert (test_list == [])

    add_default_tasks(test_list)
    # Initial: pending - 2, in-progress - 2, done - 1

    delete_by_status(test_list, 'pending')
    assert (len(test_list) == 3)

    delete_by_status(test_list, 'in-progress')
    assert (len(test_list) == 2)

    delete_by_status(test_list, 'done')
    assert (len(test_list) == 0)
