import random
from collections import defaultdict
from typing import List

from colorama import Fore, Style

from greedy.flight import Flight


def get_max_number_of_overlaps(flights: List[Flight]):
    max_flights_at_a_time = 0
    current_number_of_flights = 0

    flight_timeline = []

    for i in range(len(flights)):
        flight_timeline.append([flights[i].ora_plecare, 'x'])
        flight_timeline.append([flights[i].ora_sosire, 'y'])

    flight_timeline = sorted(flight_timeline)

    for i in range(len(flight_timeline)):
        if flight_timeline[i][1] == 'x':
            current_number_of_flights += 1

        if flight_timeline[i][1] == 'y':
            current_number_of_flights -= 1

        max_flights_at_a_time = max(max_flights_at_a_time, current_number_of_flights)

    return max_flights_at_a_time


def overlaps_with_list(flight, list_of_flights):
    for flight_from_list in list_of_flights:
        if (flight_from_list.ora_plecare <= flight.ora_plecare <= flight_from_list.ora_sosire or
                flight_from_list.ora_plecare <= flight.ora_sosire <= flight_from_list.ora_sosire):
            return True
    return False


def get_labels_of_overlapping_flights(current_flight, labeled_flights):
    # labels assigned to overlapping flights
    assigned_labels = []
    for label, flights_with_crt_label in labeled_flights.items():
        if overlaps_with_list(current_flight, flights_with_crt_label):
            assigned_labels.append(label)
    return assigned_labels


def assign_operators(flights):
    d = get_max_number_of_overlaps(flights)
    labeled_flights = defaultdict(list)

    for i in range(len(flights)):
        current_flight = flights[i]
        labels_of_overlapping = get_labels_of_overlapping_flights(current_flight, labeled_flights)
        available_labels = [label for label in range(d) if label not in labels_of_overlapping]

        crt_label = random.choice(available_labels)

        labeled_flights[crt_label].append(current_flight)

    return labeled_flights


flight1 = Flight("Roma", "Berlin", 3, 4)
flight2 = Flight("Cluj", "Madrid", 5, 9)
flight3 = Flight("Paris", "Milano", 1, 2)
flight4 = Flight("Viena", "Cluj", 5, 7)
flight5 = Flight("New York", "Londra", 0, 6)
flight6 = Flight("Cluj", "Bucuresti", 8, 9)

all_flights = [flight1, flight2, flight3, flight4, flight5, flight6]
operator_assignments = assign_operators(all_flights)
for operator, flights in operator_assignments.items():
    print('Operator ' + Fore.MAGENTA +'#'+ str(operator) + Style.RESET_ALL + ' will manage the following flights:')
    for flight in flights:
        print(flight)
