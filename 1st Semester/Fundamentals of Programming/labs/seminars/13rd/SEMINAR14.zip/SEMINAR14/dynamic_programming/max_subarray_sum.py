def max_subarray_sum(arr):
    max_sums = [arr[0]] + [0] * (len(arr) - 1)
    max_sum = arr[0]
    end_index = 0
    for i in range(1, len(arr)):
        max_sums[i] = max(max_sums[i - 1] + arr[i], arr[i])
        if max_sums[i] > max_sum:
            max_sum = max_sums[i]
            end_index = i

    return end_index, max_sum


def max_subarray_kadane(arr):
    #version in which we do not use extra memory
    max_ending_here = arr[0]
    max_sum = arr[0]
    end_index = 0
    for i in range(1, len(arr)):
        max_ending_here = max(max_ending_here + arr[i], arr[i])
        if max_ending_here > max_sum:
            max_sum = max_ending_here
            end_index = i

    return end_index, max_sum


def test_max_subarray_sum():
    arr1 = [2, -3, 4, -1, -2, 1, 5, -3]
    assert (max_subarray_sum(arr1) == 6, 7)
    assert (max_subarray_kadane(arr1) == 6, 7)

    arr1 = [-4, 5, 7, -6, 10, -15, 3]
    assert (max_subarray_sum(arr1) == 5, 16)
    assert (max_subarray_kadane(arr1) == 5, 16)
