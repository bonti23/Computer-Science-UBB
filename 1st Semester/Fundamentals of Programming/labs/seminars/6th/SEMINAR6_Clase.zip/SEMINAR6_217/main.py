from domain.task_manager import TaskManager
from domain.validator import TaskValidator
from ui.consola import Console

task_validator = TaskValidator()
task_manager = TaskManager(task_validator)
console = Console(task_manager)

console.run()
