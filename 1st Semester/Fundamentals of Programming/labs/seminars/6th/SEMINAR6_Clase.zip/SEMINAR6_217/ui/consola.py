import copy

from colorama import Fore, Style

from domain.task_manager import TaskManager


class Console:
    def __init__(self, task_manager: TaskManager):
        self.__task_manager = task_manager

    def __print_menu(self):
        print('1. Adaugare task')
        print('2. Cautare task cu deadline intre 2 date')
        print('3. Stergere task dupa descriere')
        print('4. Eliminare task-uri dupa status')
        print('5. Filtrare: afisare task-uri carre contin in descriere string')
        print('6. Afisare raport pe luna')
        print('P. Afisarea tuturor task-urilor')
        print('A. Adaugare task-uri default')
        print('E. Iesire')

    def print_task_list(self, task_list):
        for task in task_list:
            print(task)

    def search_task_ui(self):

        print('Introduceti datele:')
        try:
            zi_start = int(input('Zi start:'))
            luna_start = int(input('Luna start:'))
            zi_finish = int(input('Zi finish:'))
            luna_finish = int(input('Luna finish:'))
            lista_taskuri_intre_date = self.__task_manager.search_by_date(zi_start, luna_start, zi_finish, luna_finish)
            if len(lista_taskuri_intre_date) > 0:
                print('Exista task intre datele date. Task-urile gasite sunt:')
                self.print_task_list(lista_taskuri_intre_date)
            else:
                print(Fore.MAGENTA + "Nu exista task intre datele date." + Style.RESET_ALL)
        except ValueError:
            print(Fore.RED + 'EROARE: Introduceti numere pentru date.' + Style.RESET_ALL)

    def add_task_ui(self):
        descriere = input("Introduceti descrierea:")
        data = input("Introduceti data:")
        status = input("Introduceti status:")
        try:
            zi, luna = data.split('-')
            zi = int(zi)
            luna = int(luna)
            self.__task_manager.add_task(descriere, zi, luna, status)
        except ValueError as e:
            print(Fore.RED + 'EROARE:' + str(e) + Style.RESET_ALL)

    def delete_by_description_ui(self):
        descriere = input("Introduceti descrierea dupa care se sterge:")
        try:
            self.__task_manager.delete_task_by_description(descriere)
            print("Dupa stergere, lista cu task-uri este:")
            self.print_task_list(self.__task_manager.get_all_tasks())
        except IndexError as e:
            print(Fore.RED + 'EROARE: ' + str(e) + Style.RESET_ALL)

    def delete_by_status_ui(self):
        status = input("Introduceti statusul dupa care se sterge:")

        self.__task_manager.delete_by_status(status)
        print("Dupa stergere, lista cu task-uri este:")
        self.print_task_list(self.__task_manager.get_all_tasks())

    def show_report_ui(self):
        report = self.__task_manager.get_report_by_day()
        # report is a dict
        for day, tasks in report.items():
            print('Ziua:', day)
            self.print_task_list(tasks)

    def filter_by_description_ui(self):
        descriere_substr = input('Introduceti parte din descriere:')
        filtered_tasks = self.__task_manager.filter_by_description(descriere_substr)

        if len(filtered_tasks) > 0:
            print('Task-urile care contin in descriere textul dat sunt:')
            self.print_task_list(filtered_tasks)
        else:
            print(Fore.MAGENTA + "Nu exista task-uri pentru care descrierea contine string-ul dat." + Style.RESET_ALL)

    def run(self):

        while True:
            self.__print_menu()
            option = input('>')
            option = option.upper().strip()
            if option == "P":
                self.print_task_list(self.__task_manager.get_all_tasks())
            elif option == "A":
                self.__task_manager.add_default_tasks()
            elif option == '1':
                self.add_task_ui()
            elif option == '2':
                self.search_task_ui()
            elif option == '3':
                self.delete_by_description_ui()
            elif option == '4':
                self.delete_by_status_ui()
            elif option == '5':
                self.filter_by_description_ui()
            elif option == '6':
                self.show_report_ui()
            elif option == "E":
                break
            else:
                print("Invalid option.")
