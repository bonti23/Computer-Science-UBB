from domain.task_manager import TaskManager
from domain.validator import TaskValidator


def test_add():
    validator = TaskValidator()
    task_manager = TaskManager(validator)
    task_manager.add_task('HostMovieMarathon', 10, 8, 'pending')
    test_task_list = task_manager.get_all_tasks()
    assert (len(test_task_list) == 1)
    added_task = task_manager.find_task('HostMovieMarathon', 10, 8)
    assert (added_task is not None)
    assert (added_task.get_status() == 'pending')

    try:
        task_manager.add_task("M", 10, 5, 'not-valid-status')
        assert False
    except ValueError:
        assert True


def test_search_by_date():
    validator = TaskValidator()
    task_manager = TaskManager(validator)

    assert (task_manager.search_by_date(5, 5, 10, 8) == [])

    task_manager.add_task('HostMovieMarathon', 10, 8, 'pending')
    task_manager.add_task('Read Book', 5, 3, 'pending')
    task_manager.add_task('Build Treehouse', 1, 10, 'pending')

    assert (len(task_manager.search_by_date(5, 5, 6, 11)) == 2)

    task_manager.add_task('HostMovieMarathon', 5, 8, 'pending')

    assert (len(task_manager.search_by_date(5, 5, 6, 11)) == 3)

    task_manager.add_task('HostMovieMarathon', 1, 11, 'pending')

    assert (len(task_manager.search_by_date(5, 5, 6, 11)) == 4)
    assert (len(task_manager.search_by_date(5, 5, 1, 11)) == 4)


def test_delete_task_by_description():
    task_validator = TaskValidator()
    task_manager = TaskManager(task_validator)

    try:
        task_manager.delete_task_by_description("Read Book")
        assert False
    except IndexError:
        assert True

    assert (len(task_manager.get_all_tasks()) == 0)

    task_manager.add_task('HostMovieMarathon', 10, 8, 'pending')
    task_manager.add_task('Read Book', 5, 3, 'pending')
    task_manager.add_task('Build Treehouse', 1, 10, 'pending')

    task_manager.delete_task_by_description("Read Book")
    assert (len(task_manager.get_all_tasks()) == 2)
    try:
        task_manager.delete_task_by_description("Travel")
        assert False
    except IndexError:
        assert True
    assert (len(task_manager.get_all_tasks()) == 2)


def test_filter_by_description():
    task_validator = TaskValidator()
    task_manager = TaskManager(task_validator)
    task_manager.add_task("Travel to see Grand Canyon", 11, 9, 'pending')
    task_manager.add_task("Travel abroad", 10, 5, 'pending')
    task_manager.add_task("Try new banana bread recipe", 11, 2, "done")
    task_manager.add_task("Host a Halloween party", 31, 10, 'in-progress')
    task_manager.add_task("Buy stuff for New Year party", 28, 12, "pending")

    filtered_by_travel = task_manager.filter_by_description('travel')
    assert (len(filtered_by_travel) == 2)
    assert (len(task_manager.get_all_tasks()) == 5)

    filtered_by_recipe = task_manager.filter_by_description('recipe')
    assert (len(filtered_by_recipe) == 1)
    assert (len(task_manager.get_all_tasks()) == 5)

    filtered_by_cook = task_manager.filter_by_description('cook')
    assert (len(filtered_by_cook) == 0)
    assert (len(task_manager.get_all_tasks()) == 5)


def test_find_by_description():
    task_validator = TaskValidator()
    task_manager = TaskManager(task_validator)
    task_manager.add_task("Travel to see Grand Canyon", 11, 9, 'pending')
    task_manager.add_task("Travel abroad", 10, 5, 'pending')
    task_manager.add_task("Try new banana bread recipe", 11, 2, "done")
    task_manager.add_task("Host a Halloween party", 31, 10, 'in-progress')
    task_manager.add_task("Buy stuff for New Year party", 28, 12, "pending")

    task = task_manager.find_task("Travel to see Grand Canyon", 11, 9)
    assert (task is not None)
    assert (task.get_zi_deadline() == 11)
    assert (task.get_luna_deadline() == 9)
    assert (task.get_status() == 'pending')

    task = task_manager.find_task("Travel to see Grand Canyon", 10, 9)
    assert (task is None)

    task = task_manager.find_task("Canyon", 11, 9)
    assert (task is None)

    task = task_manager.find_task("Travel", 11, 9)
    assert (task is None)

    task = task_manager.find_task("Travel to see GRAND CANYON", 11, 9)
    assert (task is None)


def test_delete_by_status():
    task_validator = TaskValidator()
    task_manager = TaskManager(task_validator)

    task_manager.delete_by_status('pending')
    assert (len(task_manager.get_all_tasks()) == 0)

    task_manager.add_default_tasks()
    # Initial: pending - 3, in-progress - 2, done - 4

    task_manager.delete_by_status('pending')
    assert (len(task_manager.get_all_tasks()) == 6)

    task_manager.delete_by_status('in-progress')
    assert (len(task_manager.get_all_tasks()) == 4)

    task_manager.delete_by_status('done')
    assert (len(task_manager.get_all_tasks()) == 0)


def test_get_report_by_day():
    task_validator = TaskValidator()
    task_manager = TaskManager(task_validator)

    report_dict = task_manager.get_report_by_day()
    assert (len(report_dict.keys()) == 0)
    # also works with assert (not report_dict)
    task_manager.add_default_tasks()

    report_dict = task_manager.get_report_by_day()
    assert (len(report_dict['4/4']) == 1)

    assert (len(report_dict['5/8']) == 2)

    assert (len(report_dict['12/9']) == 3)

    try:
        number_of_tasks = len(report_dict['1-1'])
        assert False
    except KeyError:
        assert True
