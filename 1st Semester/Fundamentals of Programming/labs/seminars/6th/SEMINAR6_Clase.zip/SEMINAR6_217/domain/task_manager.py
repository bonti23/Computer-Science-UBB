from domain.task import Task


class TaskManager:
    def __init__(self, task_validator):
        self.__task_validator = task_validator
        self.__task_list = []

    def find_task(self, descriere, zi, luna) -> Task:
        """
        Gaseste task dupa descriere, zi, luna date
        :return: Task cu descriere, zi, luna date, None altfel
        """
        task_to_compare = Task(descriere, zi, luna, "pending")
        for task in self.__task_list:
            # functioneaza fiindca egalitatea este definita intre descriere, zi, luna intre 2 task-uri
            if task == task_to_compare:
                return task
        return None

    def add_task(self, descriere: str, zi: int, luna: int, status: str) -> None:
        """
        Adauga un task in lista de task-uri
        :param task_list: lista de task-uri
        :type task_list: list
        :param task: task-ul de adaugat
        :type task: dict
        :return: -; modifica lista prin adaugarea la sfarsit a task-ului
        :rtype:
        :raises: ValueError daca task-ul de adaugat nu este valid
        """

        task = Task(descriere, zi, luna, status)
        self.__task_validator.validate_task(task)

        self.__task_list.append(task)

    def add_default_tasks(self):
        self.add_task('Read book', 11, 10, 'pending')
        self.add_task('Host movie marathon', 5, 8, 'done')
        self.add_task('Travel to uncharted island', 10, 1, 'in-progress')
        self.add_task('Build treehouse', 12, 9, 'pending')
        self.add_task('Book Skydiving Adventure', 4, 4, 'done')
        self.add_task('Learn to ski', 21, 11, 'done')
        self.add_task('Master Art of Origami', 5, 8, 'in-progress')
        self.add_task('Dance to 80\'s music', 12, 9, 'pending')
        self.add_task('Learn to play guitar', 12, 9, 'done')

    def delete_by_status(self, status: str) -> None:

        """
        Sterge task-urile din list care au statusul dat
        :param status: statusul dupa care se sterge
        :return: -; lista se modifica prin eliminarea task-urilor cu statusul dat
        """


        current_list_length = len(self.__task_list)
        i = 0
        while i < current_list_length:
            task = self.__task_list[i]
            if task.get_status() == status:
                self.__task_list.pop(i)
                current_list_length -= 1
            else:
                i += 1
        # or: self.__task_list = [task for task in self.__task_list if task.get_status()!=status]

    def delete_task_by_description(self, description: str):
        """
        Sterge task-ul dupa descriere
        :param description: descrierea dupa care se sterge
        :return: -; lista curenta se modifica prin stergerea elementelor
        """
        # Presupunem ca exista doar 1 task cu descrierea data

        index_to_remove = -1
        for i, task in enumerate(self.__task_list):
            if task.get_descriere() == description:
                index_to_remove = i
                break
        if index_to_remove != -1:
            self.__task_list.pop(index_to_remove)
        else:
            raise IndexError("Nu exista task cu descrierea data.")



    def search_by_date(self, zi_start: int, luna_start: int, zi_end: int, luna_end: int) -> list:
        """
        Cauta un task cu data intre 2 date date
        :param task_list: lista de task-uri
        :param zi_start: ziua datei de inceput
        :param luna_start: luna datei de inceput
        :param zi_end: ziua datei de sfarsit
        :param luna_end: luna datei de sfarsit
        :return: o noua lista cu task-urile care sunt intre datele date
        """
        # TO-DO: refactor for cleaner version
        # See here some options: https://stackoverflow.com/questions/5464410/how-to-tell-if-a-date-is-between-two-other-dates)

        task_with_date_list = []
        for task in self.__task_list:
            if luna_start < task.get_luna_deadline() < luna_end:
                task_with_date_list.append(task)
            elif task.get_luna_deadline() == luna_start:
                if luna_start == luna_end:
                    if zi_start <= task.get_zi_deadline() <= zi_end:
                        task_with_date_list.append(task)
                else:
                    if zi_start <= task.get_zi_deadline():
                        task_with_date_list.append(task)
            elif task.get_luna_deadline() == luna_end:
                if luna_start == luna_end:
                    if zi_start <= task.get_zi_deadline() <= zi_end:
                        task_with_date_list.append(task)
                else:
                    if zi_end >= task.get_zi_deadline():
                        task_with_date_list.append(task)

        return task_with_date_list

    def filter_by_description(self, description: str) -> list:
        """
        Returneaza lista cu task-urile care contin in descriere un string dat
        :param task_list: lista de task-uri
        :param description: substring-ul dupa care se cauta
        :return: o lista in care se regasesc doar task-urile care au in descriere string-ul dat
        """
        return [task for task in self.__task_list if description.lower() in task.get_descriere().lower()]

    def get_report_by_day(self) -> dict:
        """
        Face un raport de activitati pe data
        :param task_list: lista de task-uri
        :return: dictionar cu cheie data (str format din zi si luna) si valoare lista
                aferenta de task-uri care au deadline in ziua respectiva
        """
        day_dictionary = {}
        for task in self.__task_list:
            if task.get_date() in day_dictionary:
                day_dictionary[task.get_date()].append(task)
            else:
                day_dictionary[task.get_date()] = [task]
        return day_dictionary

    def get_all_tasks(self) -> list:
        """
        Returneaza lista cu toate task-urile

        """
        return self.__task_list
