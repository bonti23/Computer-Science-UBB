from ui.consola import start_program

start_program()
