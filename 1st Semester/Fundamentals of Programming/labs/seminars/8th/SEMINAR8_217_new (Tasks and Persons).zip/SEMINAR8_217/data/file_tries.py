# deschid fisier ca sa citesc continutul (r)
from pprint import pprint

from domain.task import Task


# readlines, read, readline
# pprint(f.readline())
def read_tasks():
    f = open('tasks.txt', mode='r')

    tasks = []
    lines = f.readlines()
    for line in lines:
        elements = line.split(',')
        elements = [element.strip() for element in elements]
        id = int(elements[0])
        descriere = elements[1]
        zi = int(elements[2])
        luna = int(elements[3])
        status = elements[4]
        task = Task(id, descriere, zi, luna, status)
        tasks.append(task)
    return tasks


tasks = read_tasks()


# for task in tasks:
#     print(task)


# deschidem fisier pentru scriere
# a = append
# w = write

# Extra-reading: deschidere cu a+, r+, w+
def write_tasks(task_list):
    f = open('tasks1.txt', mode='w')
    for task in task_list:
        task_elements = [task.get_id(), task.get_descriere(), task.get_zi_deadline(), task.get_luna_deadline(),
                         task.get_status()]
        task_elements = [str(element) for element in task_elements]
        line = ', '.join(task_elements) + '\n'
        f.write(line)


write_tasks(tasks)
