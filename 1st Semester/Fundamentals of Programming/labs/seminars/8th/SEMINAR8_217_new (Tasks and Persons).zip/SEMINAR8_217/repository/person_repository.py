from domain.person import Person
from domain.task import Task


class PersonInMemoryRepository:
    def __init__(self):
        self.__persons = {}

    def store(self, person: Person):
        """
        Adauga o persoana in lista de persoane
        :param person: persoana-ul de adaugat
        :type person: Person
        :return: -; se adauga la colectia de persoane persoana data
        :rtype: -;
        :raises: ValueError daca exista deja persoana cu CNP-ul dat
        """

        # verificam daca task-ul exista deja -
        # dar definim ce inseamna ca exista deja: are acelasi id, are aceeasi descriere si date, etc...
        # In aceasta varianta: egalitate inseamna ca 2 task-uri au acelasi id
        if self.find(person.get_cnp()):
            raise ValueError("Exista deja persoana cu acest CNP.")
        self.__persons[person.get_cnp()] = person

    def find(self, cnp):
        """
        Gaseste persoana cu cnp dat
        :param cnp: cnp-ul cautat
        :type cnp: str
        :return: persoana cu cnp dat
        :rtype: Person
        """
        if cnp in self.__persons:
            return self.__persons[cnp]
        return None

    def update(self, cnp, modified_person):
        """
        Modifica detaliile unei persoane date
        :param cnp: cnp-ul persoanei care se modifica
        :type cnp: str
        :param modified_person: persoana cu detaliile modificate
        :type modified_person: Person
        :return: -; pentru persoana cu cnp cnp se modifica atributele conform
                    celor din modified_person
        :rtype: -;
        :raise: ValueError daca persoana cu cnp-ul dat nu exista
        """
        # TO-DO: How to implement update?
        if cnp not in self.__persons:
            raise ValueError("Nu exista persoana cu acest CNP.")
        self.__persons[cnp] = modified_person

    def delete(self, cnp):
        """
        Sterge persoana cu cnp dat
        :param cnp: cnp-ul persoanei care trebuie sterse
        :type cnp: str
        :return: persoana stearsa; persoana cu id dat este stearsa daca cnp exista
        :rtype: Person
        :raises: ValueError daca persoana cu cnp dat nu exista
        """
        if cnp not in self.__persons:
            raise ValueError("Nu exista persoana cu acest CNP.")
        deleted_person = self.__persons[cnp]
        del self.__persons[cnp]
        return deleted_person

    def get_all(self) -> list:
        """
        Returneaza intreaga lista de persoane
        """
        return list(self.__persons.values())

    def size(self):
        return len(self.get_all())


class PersonFileRepository(PersonInMemoryRepository):
    def __init__(self, filename):
        PersonInMemoryRepository.__init__(self)
        self.__filename = filename
        self.load_from_file()

    def load_from_file(self):
        """
        Incarca datele despre persoane din fisier
        """
        with open(self.__filename, mode='r', encoding='utf-8') as persons_file:
            lines = persons_file.readlines()
            lines = [line.strip() for line in lines if line.strip() != '']
            for line in lines:
                cnp, nume = line.split(',')
                cnp = cnp.strip()
                nume = nume.strip()
                PersonInMemoryRepository.store(self, Person(cnp, nume))

    def store(self, person: Person):
        """
        Adauga persoana data
        :param person: persoana care se adauga
        :type person: Person
        :return: -; fisierul in care se tin persoanele se modifica,
                    lista curenta de persoane se modifica prin adaugare
        :rtype: -;
        :raises: ValueError daca exista deja persoana cu CNP dat
        """
        #super()
        PersonInMemoryRepository.store(self, person)
        self.write_to_file()

    def delete(self, cnp):
        """
        Sterge persoana cu CNP dat
        :param cnp: cnp-ul persoanei de sters
        :type cnp: str
        :return: persoana cu CNP dat este stearsa din fisier, din lista curenta
        :rtype: -;
        :raises: ValueError daca nu exista persoana cu CNP dat
        """
        deleted_person = PersonInMemoryRepository.delete(self, cnp)
        self.write_to_file()
        return deleted_person

    def update(self, cnp, modified_person):
        """
        Modifica persoana cu CNP dat
        :param cnp: cnp-ul persoanei de modificat
        :type cnp: str
        :param modified_person: persoana cu datele modficate
        :type modified_person: Person
        :return: -; persoana cu CNP se modifica, daca CNP exista, atat in fisier cat si in lista curenta
        :rtype: -;
        :raises: ValueError daca nu exista persoana cu CNP dat
        """
        PersonInMemoryRepository.update(self, cnp, modified_person)
        self.write_to_file()

    def write_to_file(self):
        """
        Scrie datele persoanelor in fisier
        """
        persons = PersonInMemoryRepository.get_all(self)
        persons = [person.get_cnp() + ',' + person.get_nume() for person in persons]
        with open(self.__filename, mode='w', encoding='utf-8') as persons_file:
            text_to_write = '\n'.join(persons)
            persons_file.write(text_to_write)
