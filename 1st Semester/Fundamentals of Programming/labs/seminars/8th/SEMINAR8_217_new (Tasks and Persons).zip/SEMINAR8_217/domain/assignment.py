from domain.person import Person
from domain.task import Task


class Assignment:
    """
    Clasa de legătură: 1 persoană poate primi 1 sau mai multe assignment-uri
                       1 task poate fi atribuit 1 sau la mai multe persoane
    Atribute:
        --necesar pentru a gestiona task-uri, persoane
        --evaluare: int, între 1-10
    """

    def __init__(self, task, person, eval):
        self.__task = task
        self.__person = person
        self.__eval = eval

    def get_task(self):
        return self.__task

    def get_person(self):
        return self.__person

    def get_evaluare(self):
        return self.__eval

    def __eq__(self, other):
        return self.__task == other.get_task() and self.__person == other.get_person()

    def __str__(self):
        return str(self.__task) + '--' + str(self.__person)

