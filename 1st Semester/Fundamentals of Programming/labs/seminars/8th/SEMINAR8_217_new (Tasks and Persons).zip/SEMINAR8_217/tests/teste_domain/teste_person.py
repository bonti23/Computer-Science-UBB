from domain.person import Person


def test_create_person():
    # 2910504123456, Maya
    # 1991002122222, Daniel
    # 2920108145692, Carina
    # 1681210156348, Marc
    # 1760920213245, Alex
    # 5040703757453, Ioana
    # 6050706437566, Matei

    person = Person('6050706437566', 'Alessia')
    assert (person.get_nume() == 'Alessia')
    assert (person.get_cnp() == '6050706437566')
    assert (person.get_ziua_nasterii() == 6)
    assert (person.get_luna_nasterii() == 7)
    assert (person.get_anul_nasterii() == 2005)

    person = Person('1991002122222', 'Daniel')
    assert (person.get_nume() == 'Daniel')
    assert (person.get_cnp() == '1991002122222')
    assert (person.get_ziua_nasterii() == 2)
    assert (person.get_luna_nasterii() == 10)
    assert (person.get_anul_nasterii() == 1999)


def test_equal_persons():
    person1 = Person('6050706437566', 'Alessia')
    person2 = Person('6050706437566', 'Sandra')
    assert (person1 == person2)

    person1 = Person('6050706437566', 'Alessia')
    person2 = Person('2940706437566', 'Alessia')
    assert (person1 != person2)