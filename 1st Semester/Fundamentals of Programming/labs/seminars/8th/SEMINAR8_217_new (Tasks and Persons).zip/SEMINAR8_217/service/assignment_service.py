from collections import defaultdict

from domain.assignment import Assignment


class AssignmentController:
    def __init__(self, task_repo, person_repo, assignment_repo, assignment_validator):
        self.__task_repo = task_repo
        self.__person_repo = person_repo
        self.__assignment_repo = assignment_repo
        self.__assignment_validator = assignment_validator

    def create_assignment(self, id_task, cnp, nota_evaluare):
        """
        Adauga un assignment
        :param id_task: id-ul task-ului din assignment
        :type id_task: int
        :param cnp: cnp-ul persoanei din assignment
        :type cnp: str
        :param nota_evaluare: nota data de persoana assignment-ului
        :type nota_evaluare: float
        :return: -;
        :rtype: -;
        :raises: ValueError daca nu exista task cu id dat
                            daca nu exista persoana cu CNP dat
                            daca nota evaluarii nu este valida
                            daca exista deja assignment cu task si persoana data
        """

        task = self.__task_repo.find(id_task)
        if task is None:
            raise ValueError("Nu exista task cu id dat.")

        person = self.__person_repo.find(cnp)
        if person is None:
            raise ValueError("Nu exista persoana cu CNP dat.")

        assignment = Assignment(task, person, nota_evaluare)
        self.__assignment_validator.validate(assignment)

        self.__assignment_repo.add_assignment(assignment)

    def get_all(self):
        return self.__assignment_repo.get_all()

    def get_busiest_people(self, n: int):
        """
        Returneaza primele n persoane cu cele mai multe task-uri atribuite
        :param n: numarul de persoane
        :type n: int
        :return: lista de dictionare care contin informatiile necesare
        :rtype: list
        """


        # cheie = CNP, valoare = un nou dictionar = {'nr_taskuri':..., 'nume':...}
        # people_dict = {}
        # people_dict = defaultdict(int)
        assignments = self.__assignment_repo.get_all()
        # for assignment in assignments:
        #     if assignment.get_person().get_cnp() in people_dict:
        #         people_dict[assignment.get_person().get_cnp()] += 1
        #     else:
        #         people_dict[assignment.get_person().get_cnp()] = 1

        people_dict = {}
        for assignment in assignments:
            current_cnp = assignment.get_person().get_cnp()
            if current_cnp in people_dict:
                people_dict[current_cnp]['nr_taskuri'] += 1
            else:
                people_dict[current_cnp] = {'nume': assignment.get_person().get_nume(),
                                                          'nr_taskuri': 1}

        # sorted_tuple_list = [(cnp1, {'nr_taskuri':..., 'nume':...}), (cnp2, {'nr_taskuri':..., 'nume':...}), (cnp3, {'nr_taskuri':..., 'nume':...}),...]
        sorted_tuple_list = sorted(people_dict.items(), key=lambda item: item[1]['nr_taskuri'], reverse=True)

        busiest_n_people = sorted_tuple_list[:n]
        busiest_n_people = [information_dictionary for cnp, information_dictionary in busiest_n_people]
        return busiest_n_people

    def sort_by_fun(self):
        """
        Returneaza o lista sortata cu informatii despre task-uri si media evaluarii lor
        :return: list
        :rtype:
        """
        pass
