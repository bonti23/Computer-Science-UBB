#!/bin/bash

echo "Starting sed"

# $1 - jtl file name, without path
# $2 - dashboard results directory, without path

# Use the following syntax for sed on macOS
sed -i '' 's/"Number of samples in transaction.*"/OK/' $1
sed -i '' 's/500,OK/500,FAILED/' $1
sed -i '' 's/400,OK/400,FAILED/' $1
sed -i '' '/BeanShell/d' $1

JMETER_PATH="/Users/petrutrebecca/Desktop/evo/JMeker2022/apache-jmeter-5.5/bin/jmeter"

$JMETER_PATH -g $1 -o $2
