/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.12408759124088, "KoPercent": 0.8759124087591241};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7506655216831258, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.7703598484848485, 500, 1500, "[POST] Choose Flight"], "isController": false}, {"data": [0.7762404580152672, 500, 1500, "[POST] Choose Flight-0"], "isController": false}, {"data": [0.18181818181818182, 500, 1500, "[POST] Find Flights-4"], "isController": false}, {"data": [0.7592242194891201, 500, 1500, "[POST] Find Flights"], "isController": false}, {"data": [0.3, 500, 1500, "[POST] Choose Flight-1"], "isController": false}, {"data": [0.22727272727272727, 500, 1500, "[POST] Find Flights-3"], "isController": false}, {"data": [0.09090909090909091, 500, 1500, "[POST] Find Flights-5"], "isController": false}, {"data": [0.7739005736137667, 500, 1500, "[POST] Find Flights-0"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Choose Flight-4"], "isController": false}, {"data": [0.7903533906399236, 500, 1500, "[GET] Home Page-0"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Choose Flight-5"], "isController": false}, {"data": [0.9278892072588347, 500, 1500, "[GET] Home Page-1"], "isController": false}, {"data": [0.21428571428571427, 500, 1500, "[POST] Find Flights-2"], "isController": false}, {"data": [0.0, 500, 1500, "[POST] Choose Flight-2"], "isController": false}, {"data": [0.7889207258834766, 500, 1500, "[GET] Home Page-2"], "isController": false}, {"data": [0.43902439024390244, 500, 1500, "[POST] Find Flights-1"], "isController": false}, {"data": [0.5, 500, 1500, "[POST] Choose Flight-3"], "isController": false}, {"data": [0.37063267233238906, 500, 1500, "[GET] Home Page"], "isController": false}, {"data": [0.7745940783190067, 500, 1500, "[GET] Home Page-3"], "isController": false}, {"data": [0.7702960840496658, 500, 1500, "[GET] Home Page-4"], "isController": false}, {"data": [0.8013371537726839, 500, 1500, "[GET] Home Page-5"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 11645, 102, 0.8759124087591241, 1160.1572348647455, 118, 20076, 338.0, 3208.7999999999956, 6372.999999999967, 10446.27999999997, 9.64552189355386, 133.54142102475282, 6.326194937902552], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["[POST] Choose Flight", 1056, 8, 0.7575757575757576, 1096.565340909091, 208, 17308, 347.0, 3158.900000000001, 6246.799999999999, 9504.650000000003, 0.8763558203802522, 2.3086315485501956, 0.5024727253960614], "isController": false}, {"data": ["[POST] Choose Flight-0", 1048, 0, 0.0, 1080.7290076335876, 297, 10420, 347.0, 3168.1, 6137.849999999998, 9367.319999999998, 0.8728365438671156, 2.186533818147671, 0.4973032146078524], "isController": false}, {"data": ["[POST] Find Flights-4", 11, 2, 18.181818181818183, 2543.818181818182, 212, 7606, 1170.0, 7369.400000000001, 7606.0, 7606.0, 0.020866411337669755, 0.36907650302183576, 0.008741885218613597], "isController": false}, {"data": ["[POST] Find Flights", 1057, 13, 1.2298959318826868, 1235.4834437086095, 206, 20076, 339.0, 3913.4, 7328.099999999993, 10503.880000000005, 0.882077798093477, 2.8890173281971983, 0.4910117461552006], "isController": false}, {"data": ["[POST] Choose Flight-1", 5, 0, 0.0, 2943.4, 362, 7800, 1690.0, 7800.0, 7800.0, 7800.0, 0.00902595503630239, 0.20811877886049124, 0.003813113426469155], "isController": false}, {"data": ["[POST] Find Flights-3", 11, 0, 0.0, 4662.272727272727, 402, 10163, 5208.0, 9982.400000000001, 10163.0, 10163.0, 0.020719064553070942, 0.18291968878552375, 0.008700388435371586], "isController": false}, {"data": ["[POST] Find Flights-5", 11, 0, 0.0, 4913.636363636364, 325, 8801, 5475.0, 8670.6, 8801.0, 8801.0, 0.020861979043193778, 0.029127871485467735, 0.008780774382438006], "isController": false}, {"data": ["[POST] Find Flights-0", 1046, 0, 0.0, 1068.8049713193118, 294, 10396, 339.0, 3076.4000000000033, 5863.849999999999, 9775.479999999996, 0.8728981805163452, 2.019957570868734, 0.45526225358985634], "isController": false}, {"data": ["[POST] Choose Flight-4", 1, 0, 0.0, 7587.0, 7587, 7587, 7587.0, 7587.0, 7587.0, 7587.0, 0.13180440226703571, 2.822338992684856, 0.05521883649663899], "isController": false}, {"data": ["[GET] Home Page-0", 1047, 0, 0.0, 1042.946513849094, 295, 10425, 335.0, 2622.8000000000006, 5926.799999999992, 9776.639999999994, 0.872295010672492, 1.948897477842707, 0.3449994915257415], "isController": false}, {"data": ["[POST] Choose Flight-5", 1, 0, 0.0, 6271.0, 6271, 6271, 6271.0, 6271.0, 6271.0, 6271.0, 0.15946420028703556, 0.23436877092967628, 0.06711823273800031], "isController": false}, {"data": ["[GET] Home Page-1", 1047, 0, 0.0, 304.7507163323781, 118, 9408, 207.0, 577.6000000000001, 731.5999999999999, 1232.999999999999, 0.8716704602786348, 25.62574466892757, 0.38050458568803686], "isController": false}, {"data": ["[POST] Find Flights-2", 14, 0, 0.0, 3047.1428571428573, 434, 8056, 2274.0, 7115.5, 8056.0, 8056.0, 0.026537265903404352, 0.21425843446716963, 0.011104705507430436], "isController": false}, {"data": ["[POST] Choose Flight-2", 1, 0, 0.0, 8795.0, 8795, 8795, 8795.0, 8795.0, 8795.0, 8795.0, 0.11370096645821488, 0.8988372299602047, 0.04752345082433201], "isController": false}, {"data": ["[GET] Home Page-2", 1047, 8, 0.7640878701050621, 923.2320916905444, 206, 10571, 306.0, 2678.0000000000005, 4832.399999999996, 9302.039999999999, 0.870264869726253, 6.948224792397775, 0.3637435197683948], "isController": false}, {"data": ["[POST] Find Flights-1", 41, 0, 0.0, 2354.4634146341464, 165, 9827, 986.0, 6947.200000000004, 8789.8, 9827.0, 0.05736584437625838, 0.8661581175817917, 0.024322822878757987], "isController": false}, {"data": ["[POST] Choose Flight-3", 1, 0, 0.0, 639.0, 639, 639, 639.0, 639.0, 639.0, 639.0, 1.5649452269170578, 13.78802327856025, 0.6571547339593115], "isController": false}, {"data": ["[GET] Home Page", 1059, 44, 4.1548630783758265, 2787.074598678, 205, 19626, 929.0, 10191.0, 13756.0, 17526.00000000006, 0.8777731913645022, 61.64422342845237, 2.181975647077985], "isController": false}, {"data": ["[GET] Home Page-3", 1047, 8, 0.7640878701050621, 1013.3801337153776, 205, 10463, 317.0, 2864.2000000000025, 5389.9999999999945, 9763.039999999995, 0.8683989857896086, 7.568449889926074, 0.3646597303608708], "isController": false}, {"data": ["[GET] Home Page-4", 1047, 10, 0.9551098376313276, 1020.8252148997134, 206, 10696, 342.0, 3010.2000000000007, 5507.799999999991, 9013.159999999998, 0.8714760156815742, 18.527395349526806, 0.365100791725972], "isController": false}, {"data": ["[GET] Home Page-5", 1047, 9, 0.8595988538681948, 980.010506208214, 201, 10461, 230.0, 3406.000000000001, 5482.999999999987, 9375.36, 0.8694381287233459, 1.2507880126425603, 0.36594514988258015], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["429/Too Many Requests", 68, 66.66666666666667, 0.583941605839416], "isController": false}, {"data": ["Assertion failed", 34, 33.333333333333336, 0.291970802919708], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 11645, 102, "429/Too Many Requests", 68, "Assertion failed", 34, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["[POST] Choose Flight", 1056, 8, "429/Too Many Requests", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["[POST] Find Flights-4", 11, 2, "429/Too Many Requests", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[POST] Find Flights", 1057, 13, "429/Too Many Requests", 11, "Assertion failed", 2, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["[GET] Home Page-2", 1047, 8, "429/Too Many Requests", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["[GET] Home Page", 1059, 44, "Assertion failed", 32, "429/Too Many Requests", 12, "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Home Page-3", 1047, 8, "429/Too Many Requests", 8, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Home Page-4", 1047, 10, "429/Too Many Requests", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["[GET] Home Page-5", 1047, 9, "429/Too Many Requests", 9, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
